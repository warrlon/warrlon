package com.onenet.mq;

import com.google.protobuf.InvalidProtocolBufferException;
import org.eclipse.paho.client.mqttv3.*;

import java.util.logging.Logger;


public class PushCallback implements MqttCallback {
    private IMqttAsyncClient Client;

    private static final Logger logger = Logger.getLogger(PushCallback.class.getCanonicalName());

    public void connectionLost(Throwable cause) {
        logger.info("连接已断开");
    }

    public void messageArrived(String topic, MqttMessage message) throws InvalidProtocolBufferException {
        byte[] payload = message.getPayload();
        OnenetMq.Msg obj = OnenetMq.Msg.parseFrom(payload);
        logger.info("msg id: " + obj.getMsgid() + ", body: " + new String(obj.getData().toByteArray()));

    }


    public void deliveryComplete(IMqttDeliveryToken token) {
        Client = token.getClient();
    }


}
