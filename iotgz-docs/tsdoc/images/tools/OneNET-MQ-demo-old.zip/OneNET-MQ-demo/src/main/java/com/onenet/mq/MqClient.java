package com.onenet.mq;


import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;

public class MqClient {
    public static void main(String[] args) {
        String serverURI = "ssl://183.230.40.96:8883";
        String userName = "AF56810E0384601CA15BF6C0EDACAA706"; //MQID
        String clientID = "aaa"; //用户自定义合法的UTF-8字符串，可为空
        String accessKey = "Cs6lHKOnSM0MUO96a/8MCeBXKZ46+YBiNJ1IwyP6R/4="; //mq access_key
        String mqTopic = "mqTopic"; //mq topic
        String mqSub = "mqSub"; // mq sub

        String version = "2018-10-31"; //版本号
        String resourceName = "mqs/" + userName;  //通过MQ_ID访问MQ
        String expirationTime = System.currentTimeMillis() / 1000 + 100 * 24 * 60 * 60 + "";
        String signatureMethod = "sha1";  //签名方法，支持md5、sha1、sha256
        String password = null;
        try {
            //生成token
            password = Token.assembleToken(version, resourceName, expirationTime, signatureMethod, accessKey);
        } catch (UnsupportedEncodingException | InvalidKeyException | NoSuchAlgorithmException e) {
            e.printStackTrace();
        }

        MqttConnectOptions options;
        MqttClient client = null;
        try {
            client = new MqttClient(serverURI, clientID, new MemoryPersistence());
        } catch (MqttException e) {
            e.printStackTrace();
        }
        options = new MqttConnectOptions();
        options.setCleanSession(true); //clean session 必须设置 true
        options.setUserName(userName);
        options.setPassword(password.toCharArray());
        options.setConnectionTimeout(20);
        options.setKeepAliveInterval(60);
        options.setMqttVersion(MqttConnectOptions.MQTT_VERSION_3_1_1);
        String caCrtFile = System.getProperty("user.dir") + "\\src\\main\\resources\\mqCA\\certificate.pem"; //需用户自行指定证书路径

        try {
            options.setSocketFactory(SslUtil.getSocketFactory(caCrtFile));
        } catch (NoSuchAlgorithmException | KeyStoreException | CertificateException
                | IOException | KeyManagementException e) {
            e.printStackTrace();
        }
        try {
            client.connect(options);
        } catch (MqttException e) {
            e.printStackTrace();
        }
        client.setCallback(new PushCallback());
        try {
            //订阅 topic $sys/pb/consume/$MQ_ID/$TOPIC/$SUB ，QoS必须大于0，否则订阅失败
            client.subscribe(String.format("$sys/pb/consume/%s/%s/%s", userName, mqTopic, mqSub), 1);
        } catch (MqttException e) {
            e.printStackTrace();
        }

        while (true) ;

    }
}
