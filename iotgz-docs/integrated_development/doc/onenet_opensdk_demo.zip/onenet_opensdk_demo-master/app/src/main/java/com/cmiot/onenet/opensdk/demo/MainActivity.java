package com.cmiot.onenet.opensdk.demo;

import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.cmiot.onenet.opensdk.OpenApiOptions;
import com.cmiot.onenet.opensdk.annotations.ProductConfiguration;
import com.cmiot.onenet.opensdk.CommandListener;
import com.cmiot.onenet.opensdk.CommandReceiver;
import com.cmiot.onenet.opensdk.OpenApi;
import com.cmiot.onenet.opensdk.OpenApiCallback;
import com.cmiot.onenet.opensdk.OpenApiExtention;
import com.cmiot.onenet.opensdk.RegisterListener;
import com.cmiot.onenet.opensdk.ResponseListener;
import com.cmiot.onenet.opensdk.internal.Encrypt;
import com.cmiot.onenet.opensdk.internal.Function;
import com.cmiot.onenet.opensdk.internal.FunctionId;
import com.cmiot.onenet.opensdk.internal.OperationCode;
import com.cmiot.onenet.opensdk.internal.OperationResponse;
import com.cmiot.onenet.opensdk.internal.RegisterResponse;
import com.cmiot.onenet.opensdk.util.BytesUtil;

import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

@ProductConfiguration("opensdk-config/295238_android_sdk.json")
public class MainActivity extends AppCompatActivity {

    private static final String TAG = "OneNET-OpenSdk-Sample";

    private static final List<Method> TEST_METHODS = new ArrayList<>();

    private OpenApi mOpenApi;
    private TextView mTextViewLog;
    private OpenApiExtention mOpenApiExtention;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setupToolbar();
        initTestMethods();
        initViews();

        // v0.9.7 增加 SDK 的可选配置项
        OpenApiOptions options = new OpenApiOptions();
        options.setAcquireWakeLock(false);     // 是否防止设备休眠
        options.setAutoReConnect(false);       // 是否自动重连
        options.setAutoReConnectInterval(120); // 检查连接状态并自动重连的时间间隔
        options.setConnectionTimeout(15);      // 连接超时时间
        options.setKeepAliveInterval(240);     // keep-alive 发送间隔

        mOpenApi = new OpenApi(this, false, OpenApiExtention.PRODUCT_ID, OpenApiExtention.PRODUCT_KEY, "123456789", options,
                new OpenApiCallback() {
                    @Override
                    public void onSuccess() {
                        mTextViewLog.append("SDK初始化成功\n\n");
                        mOpenApi.register(Encrypt.x509, new RegisterListener() {
                            @Override
                            public void onResponse(RegisterResponse response) {
                                try {
                                    int responseCode = response.getResponseCode() & 0x0FF;
                                    String codeString = Integer.toHexString(responseCode);
                                    JSONObject jsonObject = new JSONObject();
                                    jsonObject.put("code", responseCode > 0x0F ? "0x" + codeString : "0x0" + codeString);
                                    if (0 == response.getResponseCode()) {
                                        jsonObject.put("deviceId", response.getDeviceId());
                                        jsonObject.put("authCode", response.getAuthCode());
                                        jsonObject.put("address", response.getMqttBroker());
                                        jsonObject.put("certificate", response.getCertificate());
                                        mTextViewLog.append("注册成功\n");

                                        invalidateOptionsMenu();
                                    } else {
                                        mTextViewLog.append("注册失败\n");
                                    }

                                    mTextViewLog.append(jsonObject.toString() + "\n\n");

                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }
                        });
                    }

                    @Override
                    public void onFailed(Throwable exception) {
                        mTextViewLog.append("SDK初始化失败\n");
                        if (exception != null) {
                            mTextViewLog.append(exception.toString() + "\n\n");
                        } else {
                            mTextViewLog.append("\n");
                        }
                    }
                });
        // 设置 SDK 调试日志打印
        mOpenApi.showDebugLog(BuildConfig.DEBUG);

        // 注册平台响应回调
        mOpenApi.setResponseListener(new ResponseListener() {
            @Override
            public void onSuccess(int messageId) {
                Log.i(TAG, "accepted, messageId = " + messageId);
                mTextViewLog.append("平台响应：{\"code\": 200, \"message\": \"success\"}\n\n");
            }

            @Override
            public void onFailed(int messageId, int code, String message) {
                Log.i(TAG, "rejected, messageId = " + messageId + ", code = " + code + ", message = " + message);
                mTextViewLog.append("平台响应：{\"code\": " + code + ", \"message\": " + message + "}\n\n");
            }
        });

        // 注册命令接收回调
        mOpenApi.setCommandListener(new CommandListener() {
            @Override
            public void onCommandReceived(String commandId, int messageId, OperationCode operationCode, Function function) {

                // 使用 OpenApiExtention 时，可在 onCommandReceived 中只加这一句代码，然后在 CommandReceiver
                // 中响应具体功能点的下发操作
                mOpenApiExtention.onCommandReceived(commandId, messageId, operationCode, function);

                // 调试日志
                Log.i(TAG, "command received, {commandId: " + commandId + ", messageId: "
                        + messageId + ", operationCode: " + operationCode.toString() + ", functionId: "
                        + function.getFunctionId().getResourceId() + ", value: " + BytesUtil.bytesToHexString(function.getValue()) + "}");

            }
        });

        mOpenApiExtention = new OpenApiExtention(mOpenApi, mCommandReceiver);
    }

    /**
     * 设置 Toolbar
     */
    private void setupToolbar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
    }

    /**
     * 找出 OpenApiExtention 类中的测试方法
     */
    private void initTestMethods() {
        if (!TEST_METHODS.isEmpty()) {
            TEST_METHODS.clear();
        }
        Method[] testMethods = OpenApiExtention.class.getMethods();
        for (Method method : testMethods) {
            if (method.getName().startsWith("test")) {
                TEST_METHODS.add(method);
            }
        }
    }

    /**
     * 设置 OptionMenu，菜单名称为对应的测试方法名
     */
    private void setupOptionMenus(Menu menu) {
        int menuId = 0;

        menu.add(0, menuId, menuId, "Clear log")
                .setIcon(R.drawable.ic_action_clear)
                .setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
        menuId++;

        for (Method method : TEST_METHODS) {
            String methodName = method.getName();
            menu.add(0, menuId, menuId, methodName);
            menuId++;
        }

    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        menu.clear();
        setupOptionMenus(menu);
        return mOpenApi.isRegistered();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (0 == item.getItemId()) {
            mTextViewLog.setText("");
        } else {
            try {
                Method method = TEST_METHODS.get(item.getItemId() - 1);
                String text = (String) method.invoke(mOpenApiExtention);
                mTextViewLog.append(text + "\n");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return mOpenApi.isRegistered();
    }

    private void initViews() {
        mTextViewLog = findViewById(R.id.text_view_log);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // 释放资源
        mOpenApi.destroy();
    }

    /**
     * 模拟设备功能点数据，用于响应平台的查询命令
     */
    private Function generateReadFunction(Function function) {
        // 获取服务端要读取的数据类型
        short dataType = function.getFunctionId().getDataTypeId();
        byte[] data = null;

        switch (dataType) {
            case FunctionId.DataTypeId.BOOL:
                data = ByteBuffer.allocate(1).put((byte) 1).array();
                break;

            case FunctionId.DataTypeId.ENUM:
                data = ByteBuffer.allocate(1).put((byte) 100).array();
                break;

            case FunctionId.DataTypeId.INT:
                data = ByteBuffer.allocate(4).putInt(10000).array();
                break;

            case FunctionId.DataTypeId.FLOAT:
                data = ByteBuffer.allocate(4).putFloat(8.88f).array();
                break;

            case FunctionId.DataTypeId.EXCEPTION:
                data = ByteBuffer.allocate(4).putInt(0xFF).array();
                break;

            case FunctionId.DataTypeId.BUFFER:
                data = BytesUtil.bytesToHexString("Test read BUFFER command".getBytes()).getBytes();
                break;

            case FunctionId.DataTypeId.STRING:
                data = "Test read STRING command".getBytes();
                break;
        }
        function.setValue(data);
        return function;
    }

    /**
     * 模拟设备功能点数据，用于响应平台的下发命令
     */
    private void handleWriteFunction(Function function) {
        // 获取服务端要读取的数据类型
        short dataType = function.getFunctionId().getDataTypeId();
        String value = null;
        switch (dataType) {
            case FunctionId.DataTypeId.BOOL:
                int bool = ByteBuffer.allocate(1).put(function.getValue()).get(0);
                value = 0 == bool ? "false" : "true";
                break;

            case FunctionId.DataTypeId.ENUM:
                value = ByteBuffer.allocate(1).put(function.getValue()).get(0) + "";
                break;

            case FunctionId.DataTypeId.INT:
                value = BytesUtil.bytesToInt(function.getValue()) + "";
                break;

            case FunctionId.DataTypeId.FLOAT:
                value = ByteBuffer.allocate(4).put(function.getValue()).getFloat() + "";
                break;

            case FunctionId.DataTypeId.EXCEPTION:
                value = Integer.toHexString(ByteBuffer.allocate(4).put(function.getValue()).getInt());
                break;

            case FunctionId.DataTypeId.BUFFER:
            case FunctionId.DataTypeId.STRING:
                value = new String(function.getValue());
                break;
        }
        mTextViewLog.append("{\"functionId:\" " + function.getFunctionId().toShort() + ", \"value\": " + value + "}");
    }

    private CommandReceiver mCommandReceiver = new CommandReceiver() {

        @Override
        public void onReceiveSwitch1(String commandId, int messageId, OperationCode operationCode, Function function, boolean isGroup) {
            // TODO 开发者自行实现，注意发送命令响应
            handleCommandSingle(commandId, messageId, operationCode, function, isGroup);
        }

        @Override
        public void onReceiveSwitch2(String commandId, int messageId, OperationCode operationCode, Function function, boolean isGroup) {
            // TODO 开发者自行实现，注意发送命令响应
            handleCommandSingle(commandId, messageId, operationCode, function, isGroup);
        }

        @Override
        public void onReceiveSwitch3(String commandId, int messageId, OperationCode operationCode, Function function, boolean isGroup) {
            // TODO 开发者自行实现，注意发送命令响应
            handleCommandSingle(commandId, messageId, operationCode, function, isGroup);
        }

        @Override
        public void onReceiveSwitch4(String commandId, int messageId, OperationCode operationCode, Function function, boolean isGroup) {
            // TODO 开发者自行实现，注意发送命令响应
            handleCommandSingle(commandId, messageId, operationCode, function, isGroup);
        }

        @Override
        public void onReceiveSwitch5(String commandId, int messageId, OperationCode operationCode, Function function, boolean isGroup) {
            // TODO 开发者自行实现，注意发送命令响应
            handleCommandSingle(commandId, messageId, operationCode, function, isGroup);
        }

        @Override
        public void onReceiveSwitch6(String commandId, int messageId, OperationCode operationCode, Function function, boolean isGroup) {
            // TODO 开发者自行实现，注意发送命令响应
            handleCommandSingle(commandId, messageId, operationCode, function, isGroup);
        }

        @Override
        public void onReceiveUSB1(String commandId, int messageId, OperationCode operationCode, Function function, boolean isGroup) {
            // TODO 开发者自行实现，注意发送命令响应
            handleCommandSingle(commandId, messageId, operationCode, function, isGroup);
        }

        @Override
        public void onReceiveUSB2(String commandId, int messageId, OperationCode operationCode, Function function, boolean isGroup) {
            // TODO 开发者自行实现，注意发送命令响应
            handleCommandSingle(commandId, messageId, operationCode, function, isGroup);
        }

        @Override
        public void onReceiveUSB3(String commandId, int messageId, OperationCode operationCode, Function function, boolean isGroup) {
            // TODO 开发者自行实现，注意发送命令响应
            handleCommandSingle(commandId, messageId, operationCode, function, isGroup);
        }

        @Override
        public void onReceiveUSB4(String commandId, int messageId, OperationCode operationCode, Function function, boolean isGroup) {
            // TODO 开发者自行实现，注意发送命令响应
            handleCommandSingle(commandId, messageId, operationCode, function, isGroup);
        }

        @Override
        public void onReceiveAddEle(String commandId, int messageId, OperationCode operationCode, Function function, boolean isGroup) {
            // TODO 开发者自行实现，注意发送命令响应
            handleCommandSingle(commandId, messageId, operationCode, function, isGroup);
        }

        @Override
        public void onReceiveReset(String commandId, int messageId, OperationCode operationCode, Function function, boolean isGroup) {
            // TODO 开发者自行实现，注意发送命令响应
            handleCommandSingle(commandId, messageId, operationCode, function, isGroup);
        }

        @Override
        public void onReceiveRestart(String commandId, int messageId, OperationCode operationCode, Function function, boolean isGroup) {
            // TODO 开发者自行实现，注意发送命令响应
            handleCommandSingle(commandId, messageId, operationCode, function, isGroup);
        }

        @Override
        public void onReceiveGroupFun(String commandId, int messageId, OperationCode operationCode, Function function) {
            if (OperationCode.METHOD_READ == operationCode.getMethod()) {
                mTextViewLog.append("收到平台组合功能点查询命令：{\"functionId:\" " + function.getFunctionId().toShort() + ", \"children\": [");
                super.onReceiveGroupFun(commandId, messageId, operationCode, function);
                mTextViewLog.append("]}\n");
                mTextViewLog.append("设备命令应答：操作成功\n");
                operationCode.setOperation(OperationCode.OPERATION_RESPONSE);
                mOpenApi.respond(commandId, messageId, operationCode, OperationResponse.SUCCESS, function);
            } else if (OperationCode.METHOD_WRITE == operationCode.getMethod()) {
                mTextViewLog.append("收到平台组合功能点写入命令：{\"functionId:\" " + function.getFunctionId().toShort() + "， \"children\": [");
                super.onReceiveGroupFun(commandId, messageId, operationCode, function);
                mTextViewLog.append("]}\n");
                mTextViewLog.append("设备命令应答：操作成功\n");
                operationCode.setOperation(OperationCode.OPERATION_RESPONSE);
                mOpenApi.respond(commandId, messageId, operationCode, OperationResponse.SUCCESS, null);
            }

        }

    };

    private void handleCommandSingle(String commandId, int messageId, OperationCode operationCode, Function function, boolean isGroup) {
        if (OperationCode.METHOD_READ == operationCode.getMethod()) {
            if (isGroup) {
                generateReadFunction(function);
                mTextViewLog.append("{\"functionId:\" " + function.getFunctionId().toShort() + "}");
                mTextViewLog.append(", ");
            } else {
                handleReadCommandSingle(commandId, messageId, operationCode, function);
            }
        } else if (OperationCode.METHOD_WRITE == operationCode.getMethod()) {
            if (isGroup) {
                handleWriteFunction(function);
                mTextViewLog.append(", ");
            } else {
                handleWriteCommandSingle(commandId, messageId, operationCode, function);
            }
        }
    }

    /**
     * 处理单个功能点查询命令
     */
    private void handleReadCommandSingle(String commandId, int messageId, OperationCode operationCode, Function function) {
        mTextViewLog.append("收到平台功能点查询命令：{\"functionId\": " + function.getFunctionId().toShort() + "}\n");
        function = generateReadFunction(function);
        mTextViewLog.append("设备命令应答：操作成功\n");
        operationCode.setOperation(OperationCode.OPERATION_RESPONSE);
        mOpenApi.respond(commandId, messageId, operationCode, OperationResponse.SUCCESS, function);
    }

    /**
     * 处理单个功能点写入命令
     */
    private void handleWriteCommandSingle(String commandId, int messageId, OperationCode operationCode, Function function) {
        mTextViewLog.append("收到平台功能点写入命令：\n");
        handleWriteFunction(function);
        mTextViewLog.append("\n设备命令应答：操作成功\n");
        operationCode.setOperation(OperationCode.OPERATION_RESPONSE);
        mOpenApi.respond(commandId, messageId, operationCode, OperationResponse.SUCCESS, null);
    }

}
