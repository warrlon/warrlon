package com.cmiot.onenet.studio.gateway.device;

import androidx.lifecycle.ViewModel;

public class DeviceViewModel extends ViewModel {
}
