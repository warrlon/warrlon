package com.cmiot.onenet.studio.demo.functions;

public interface DeleteFunction {

    void onDelete();
    
}
