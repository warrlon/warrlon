package com.cmiot.onenet.studio.demo.utils;

import com.cmiot.onenet.studio.mqtt.MqttClient;
import com.cmiot.onenet.studio.mqtt.MqttClientHelper;

public class MqttUtils {

    public static MqttClient mqttClient;
    public static MqttClientHelper mqttClientHelper;

}
