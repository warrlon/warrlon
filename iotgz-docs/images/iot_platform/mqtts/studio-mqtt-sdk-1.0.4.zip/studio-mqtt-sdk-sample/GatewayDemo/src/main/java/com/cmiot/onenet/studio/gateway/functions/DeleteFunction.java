package com.cmiot.onenet.studio.gateway.functions;

public interface DeleteFunction {

    void onDelete();
    
}
