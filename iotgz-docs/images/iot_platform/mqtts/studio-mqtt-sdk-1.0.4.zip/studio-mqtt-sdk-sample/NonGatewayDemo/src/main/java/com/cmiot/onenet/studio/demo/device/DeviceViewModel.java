package com.cmiot.onenet.studio.demo.device;

import androidx.lifecycle.ViewModel;

public class DeviceViewModel extends ViewModel {
}
