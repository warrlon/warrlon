package com.cmiot.onenet.studio.gateway.utils;

import com.cmiot.onenet.studio.mqtt.MqttClient;
import com.cmiot.onenet.studio.mqtt.MqttClientHelper;
import com.cmiot.onenet.studio.mqtt.MqttClientHelperREy3k0pk6N;

public class MqttUtils {

    public static MqttClient mqttClient;
    public static MqttClientHelper mqttClientHelper;
    public static MqttClientHelperREy3k0pk6N mqttClientHelperREy3k0pk6N;

}
