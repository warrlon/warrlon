package cmcc.iot.onenet.studio.javasdk;

import cmcc.iot.onenet.studio.javasdk.api.direct.DeviceBatchNotify;
import cmcc.iot.onenet.studio.javasdk.api.direct.DeviceEventNotify;
import cmcc.iot.onenet.studio.javasdk.api.direct.DevicePropertyNotify;
import cmcc.iot.onenet.studio.javasdk.api.direct.HistoryDataNotify;
import cmcc.iot.onenet.studio.javasdk.api.proxy.*;
import cmcc.iot.onenet.studio.javasdk.dto.Property;
import cmcc.iot.onenet.studio.javasdk.http.BaseResponse;
import org.junit.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ApiTest {

    @Test
    public void testDevicePropertyNotify(){
        //构建参数
        String pid = "7A926g5R2n";
        String deviceName = "sdqqqq";
        String pro = "MQTT";
        String id = "123";
        String version = "1.0";
        Map<String, Object> param = new HashMap<>();
        param.put("Power",new Property("112",1619142962931L));
        param.put("temp",new Property(1,1619142962931L));
        String token = "version=2018-10-31&res=products%2F7A926g5R2n%2Fdevices%2Fsdqqqq&et=1628390225&method=md5&sign=hZAd7skFQQBhkNOJP8S1TA%3D%3D";
        DevicePropertyNotify devicePropertyNotify = new DevicePropertyNotify();
        devicePropertyNotify.devicePropertyNotify(pid,deviceName,pro,id,version,param,token);
        //调用接口
        BaseResponse baseResponse = devicePropertyNotify.executeApi();
        System.out.println("errno:"+baseResponse.errno+" error:"+baseResponse.error);
    }

    @Test
    public void testDeviceEventNotify(){
        //构建参数
        String pid = "7A926g5R2n";
        String deviceName = "sdqqqq";
        String pro = "MQTT";
        String id = "123";
        String version = "1.0";
        Map<String, Object> values = new HashMap<>();
        values.put("led1",1);
        values.put("led2",1);
        Map<String, Object> param = new HashMap<>();
        param.put("switch",new Property(values,1619142962931L));
        String token = "version=2018-10-31&res=products%2F7A926g5R2n%2Fdevices%2Fsdqqqq&et=1628390225&method=md5&sign=hZAd7skFQQBhkNOJP8S1TA%3D%3D";
        DeviceEventNotify deviceEventNotify = new DeviceEventNotify();
        deviceEventNotify.deviceEventNotify(pid,deviceName,pro,id,version,param,token);
        //调用接口
        BaseResponse baseResponse = deviceEventNotify.executeApi();
        System.out.println("errno:"+baseResponse.errno+" error:"+baseResponse.error);
    }

    @Test
    public void testDeviceBatchNotify(){
        //构建参数
        String pid = "7A926g5R2n";
        String deviceName = "sdqqqq";
        String pro = "MQTT";
        String id = "123";
        String version = "1.0";
        Map<String, Object> property = new HashMap<>();
        property.put("Power",new Property("112",1619142962931L));
        property.put("temp",new Property(1,1619142962931L));
        Map<String, Object> values = new HashMap<>();
        values.put("led1",1);
        values.put("led2",1);
        Map<String, Object> event = new HashMap<>();
        event.put("switch",new Property(values,1619142962931L));
        Map<String, Object> param = new HashMap<>();
        param.put("properties",property);
        param.put("events",event);
        String token = "version=2018-10-31&res=products%2F7A926g5R2n%2Fdevices%2Fsdqqqq&et=1628390225&method=md5&sign=hZAd7skFQQBhkNOJP8S1TA%3D%3D";
        DeviceBatchNotify deviceBatchNotify = new DeviceBatchNotify();
        deviceBatchNotify.deviceBatchNotify(pid,deviceName,pro,id,version,param,token);
        //调用接口
        BaseResponse baseResponse = deviceBatchNotify.executeApi();
        System.out.println("errno:"+baseResponse.errno+" error:"+baseResponse.error);
    }

    @Test
    public void testHistoryDataNotify(){
        //构建参数
        String pid = "7A926g5R2n";
        String deviceName = "sdqqqq";
        String pro = "MQTT";
        String id = "123";
        String version = "1.0";
        Map<String, Object> property = new HashMap<>();
        List<Property> Powers = new ArrayList<>();
        Powers.add(new Property("112",1619142962931L));
        property.put("Power",Powers);
        List<Property> temps = new ArrayList<>();
        temps.add(new Property(1,1619142962931L));
        property.put("temp",temps);
        Map<String, Object> values = new HashMap<>();
        values.put("led1",1);
        values.put("led2",1);
        Map<String, Object> event = new HashMap<>();
        List<Property> switchs = new ArrayList<>();
        switchs.add(new Property(values,1619142962931L));
        event.put("switch",switchs);
        Map<String, Object> param = new HashMap<>();
        param.put("properties",property);
        param.put("events",event);
        List<Object> params = new ArrayList<>();
        params.add(param);
        String token = "version=2018-10-31&res=products%2F7A926g5R2n%2Fdevices%2Fsdqqqq&et=1628390225&method=md5&sign=hZAd7skFQQBhkNOJP8S1TA%3D%3D";
        HistoryDataNotify historyDataNotify = new HistoryDataNotify();
        historyDataNotify.historyDataNotify(pid,deviceName,pro,id,version,params,token);
        //调用接口
        BaseResponse baseResponse = historyDataNotify.executeApi();
        System.out.println("errno:"+baseResponse.errno+" error:"+baseResponse.error);
    }

    @Test
    public void testSubDevicePropertyNotify(){
        //构建参数
        String pid = "4Co7egrJip";
            String deviceName = "wangguan";
        String pro = "MQTT";
        String id = "123";
        String version = "1.0";
        Map<String, Object> param = new HashMap<>();
        Map<String, Object> property = new HashMap<>();
        Map<String, Object> identity = new HashMap<>();

        property.put("FcRecordOn",new Property(0,1619142962931L));
        property.put("FcInterfaceType",new Property(1,1619142962931L));
        param.put("properties",property);
        identity.put("productID","CxI02O7N29");
        identity.put("deviceName","son");
        param.put("identity",identity);
        List<Object> params  = new ArrayList<>();
        params.add(param);
        String token = "version=2018-10-31&res=products%2F4Co7egrJip%2Fdevices%2Fwangguan&et=1628390225&method=md5&sign=vzJ3fwLG7Y0AzHbbeJSSMw%3D%3D";
        SubDevicePropertyNotify subDevicePropertyNotify = new SubDevicePropertyNotify();
        subDevicePropertyNotify.subDevicePropertyNotify(pid,deviceName,pro,id,version,params,token);
        //调用接口
        BaseResponse baseResponse = subDevicePropertyNotify.executeApi();
        System.out.println("errno:"+baseResponse.errno+" error:"+baseResponse.error);
    }

    @Test
    public void testSubDeviceEventNotify(){
        //构建参数
        String pid = "4Co7egrJip";
        String deviceName = "wangguan";
        String pro = "MQTT";
        String id = "123";
        String version = "1.0";
        Map<String, Object> param = new HashMap<>();
        Map<String, Object> event = new HashMap<>();
        Map<String, Object> identity = new HashMap<>();
        Map<String, Object> value = new HashMap<>();
        value.put("aqq",1);
        event.put("qqaz",new Property(value,1619142962931L));
        param.put("events",event);
        identity.put("productID","CxI02O7N29");
        identity.put("deviceName","son");
        param.put("identity",identity);
        List<Object> params  = new ArrayList<>();
        params.add(param);
        String token = "version=2018-10-31&res=products%2F4Co7egrJip%2Fdevices%2Fwangguan&et=1628390225&method=md5&sign=vzJ3fwLG7Y0AzHbbeJSSMw%3D%3D";
        SubDeviceEventNotify subDeviceEventNotify = new SubDeviceEventNotify();
        subDeviceEventNotify.subDeviceEventNotify(pid,deviceName,pro,id,version,params,token);
        //调用接口
        BaseResponse baseResponse = subDeviceEventNotify.executeApi();
        System.out.println("errno:"+baseResponse.errno+" error:"+baseResponse.error);
    }

    @Test
    public void testSubDeviceBatchNotify(){
        //构建参数
        String pid = "4Co7egrJip";
        String deviceName = "wangguan";
        String pro = "MQTT";
        String id = "123";
        String version = "1.0";
        Map<String, Object> param = new HashMap<>();
        Map<String, Object> event = new HashMap<>();
        Map<String, Object> identity = new HashMap<>();
        Map<String, Object> value = new HashMap<>();
        Map<String, Object> property = new HashMap<>();
        property.put("FcRecordOn",new Property(0,1619142962931L));
        property.put("FcInterfaceType",new Property(1,1619142962931L));
        param.put("properties",property);
        value.put("aqq",1);
        event.put("qqaz",new Property(value,1619142962931L));
        param.put("events",event);
        identity.put("productID","CxI02O7N29");
        identity.put("deviceName","son");
        param.put("identity",identity);
        List<Object> params  = new ArrayList<>();
        params.add(param);
        String token = "version=2018-10-31&res=products%2F4Co7egrJip%2Fdevices%2Fwangguan&et=1628390225&method=md5&sign=vzJ3fwLG7Y0AzHbbeJSSMw%3D%3D";
        SubDeviceBatchNotify subDeviceBatchNotify = new SubDeviceBatchNotify();
        subDeviceBatchNotify.subDeviceBatchNotify(pid,deviceName,pro,id,version,params,token);
        //调用接口
        BaseResponse baseResponse = subDeviceBatchNotify.executeApi();
        System.out.println("errno:"+baseResponse.errno+" error:"+baseResponse.error);
    }

    @Test
    public void testSubDeviceHistoryNotify(){
        //构建参数
        String pid = "4Co7egrJip";
        String deviceName = "wangguan";
        String pro = "MQTT";
        String id = "123";
        String version = "1.0";
        Map<String, Object> param = new HashMap<>();
        Map<String, Object> event = new HashMap<>();
        Map<String, Object> identity = new HashMap<>();
        Map<String, Object> value = new HashMap<>();
        Map<String, Object> property = new HashMap<>();
        List<Object> fcRecordOn = new ArrayList<>();
        fcRecordOn.add(new Property(0,1619142962931L));
        property.put("FcRecordOn",fcRecordOn);
        param.put("properties",property);
        value.put("aqq",1);
        List<Object> qqaz = new ArrayList<>();
        qqaz.add(new Property(value,1619142962931L));
        event.put("qqaz",qqaz);
        param.put("events",event);
        identity.put("productID","CxI02O7N29");
        identity.put("deviceName","son");
        param.put("identity",identity);
        List<Object> params  = new ArrayList<>();
        params.add(param);
        String token = "version=2018-10-31&res=products%2F4Co7egrJip%2Fdevices%2Fwangguan&et=1628390225&method=md5&sign=vzJ3fwLG7Y0AzHbbeJSSMw%3D%3D";
        SubDeviceHistoryNotify subDeviceHistoryNotify = new SubDeviceHistoryNotify();
        subDeviceHistoryNotify.subDeviceHistoryNotify(pid,deviceName,pro,id,version,params,token);
        //调用接口
        BaseResponse baseResponse = subDeviceHistoryNotify.executeApi();
        System.out.println("errno:"+baseResponse.errno+" error:"+baseResponse.error);
    }

    @Test
    public void testSubDeviceLogin(){
        //构建参数
        String pid = "4Co7egrJip";
        String deviceName = "wangguan";
        String pro = "MQTT";
        String id = "123";
        String version = "1.0";
        Map<String, Object> param = new HashMap<>();

        param.put("productID","CxI02O7N29");
        param.put("deviceName","son");
        String token = "version=2018-10-31&res=products%2F4Co7egrJip%2Fdevices%2Fwangguan&et=1628390225&method=md5&sign=vzJ3fwLG7Y0AzHbbeJSSMw%3D%3D";
        SubDeviceLogin subDeviceLogin = new SubDeviceLogin();
        subDeviceLogin.subDeviceLogin(pid,deviceName,pro,id,version,param,token);
        //调用接口
        BaseResponse baseResponse = subDeviceLogin.executeApi();
        System.out.println("errno:"+baseResponse.errno+" error:"+baseResponse.error);
    }

    @Test
    public void testSubDeviceLogout(){
        //构建参数
        String pid = "4Co7egrJip";
        String deviceName = "wangguan";
        String pro = "MQTT";
        String id = "123";
        String version = "1.0";
        Map<String, Object> param = new HashMap<>();

        param.put("productID","CxI02O7N29");
        param.put("deviceName","son");
        String token = "version=2018-10-31&res=products%2F4Co7egrJip%2Fdevices%2Fwangguan&et=1628390225&method=md5&sign=vzJ3fwLG7Y0AzHbbeJSSMw%3D%3D";
        SubDeviceLogout subDeviceLogout = new SubDeviceLogout();
        subDeviceLogout.subDeviceLogout(pid,deviceName,pro,id,version,param,token);
        //调用接口
        BaseResponse baseResponse = subDeviceLogout.executeApi();
        System.out.println("errno:"+baseResponse.errno+" error:"+baseResponse.error);
    }

    @Test
    public void testAddSubDevice(){
        //构建参数
        String pid = "4Co7egrJip";
        String deviceName = "wangguan";
        String pro = "MQTT";
        String id = "123";
        String version = "1.0";
        Map<String, Object> param = new HashMap<>();

        param.put("productID","CxI02O7N29");
        param.put("deviceName","sontwo");
        param.put("sasToken","version=2018-10-31&res=products%2FCxI02O7N29%2Fdevices%2Fsontwo&et=1628390225&method=md5&sign=LslhemXPeSOoU2Wj6KfYyQ%3D%3D");
        String token = "version=2018-10-31&res=products%2F4Co7egrJip%2Fdevices%2Fwangguan&et=1628390225&method=md5&sign=vzJ3fwLG7Y0AzHbbeJSSMw%3D%3D";
        AddSubDevice addSubDevice = new AddSubDevice();
        addSubDevice.addSubDevice(pid,deviceName,pro,id,version,param,token);
        //调用接口
        BaseResponse baseResponse = addSubDevice.executeApi();
        System.out.println("errno:"+baseResponse.errno+" error:"+baseResponse.error);
    }

    @Test
    public void testDeleteSubDevice(){
        //构建参数
        String pid = "4Co7egrJip";
        String deviceName = "wangguan";
        String pro = "MQTT";
        String id = "123";
        String version = "1.0";
        Map<String, Object> param = new HashMap<>();

        param.put("productID","CxI02O7N29");
        param.put("deviceName","sontwo");
        param.put("sasToken","version=2018-10-31&res=products%2FCxI02O7N29%2Fdevices%2Fsontwo&et=1628390225&method=md5&sign=LslhemXPeSOoU2Wj6KfYyQ%3D%3D");
        String token = "version=2018-10-31&res=products%2F4Co7egrJip%2Fdevices%2Fwangguan&et=1628390225&method=md5&sign=vzJ3fwLG7Y0AzHbbeJSSMw%3D%3D";
        DeleteSubDevice deleteSubDevice = new DeleteSubDevice();
        deleteSubDevice.deleteSubDevice(pid,deviceName,pro,id,version,param,token);
        //调用接口
        BaseResponse baseResponse = deleteSubDevice.executeApi();
        System.out.println("errno:"+baseResponse.errno+" error:"+baseResponse.error);
    }

    @Test
    public void testGetTopo(){
        //构建参数
        String pid = "4Co7egrJip";
        String deviceName = "wangguan";
        String pro = "MQTT";
        String id = "123";
        String version = "1.0";
        Map<String, Object> param = new HashMap<>();
        param.put("sasToken","version=2018-10-31&res=products%2FCxI02O7N29%2Fdevices%2Fsontwo&et=1628390225&method=md5&sign=LslhemXPeSOoU2Wj6KfYyQ%3D%3D");
        String token = "version=2018-10-31&res=products%2F4Co7egrJip%2Fdevices%2Fwangguan&et=1628390225&method=md5&sign=vzJ3fwLG7Y0AzHbbeJSSMw%3D%3D";
        GetTopo getTopo = new GetTopo();
        getTopo.getTopo(pid,deviceName,pro,id,version,param,token);
        //调用接口
        BaseResponse baseResponse = getTopo.executeApi();
        System.out.println("errno:"+baseResponse.errno+" error:"+baseResponse.error + " data:" + baseResponse.data);
    }
}
