package cmcc.iot.onenet.studio.javasdk.exception;

public class OnenetStudioApiException extends RuntimeException {
    private String message = null;
    public String getMessage() {
        return message;
    }
    public OnenetStudioApiException( String message) {
        this.message = message;
    }
}
