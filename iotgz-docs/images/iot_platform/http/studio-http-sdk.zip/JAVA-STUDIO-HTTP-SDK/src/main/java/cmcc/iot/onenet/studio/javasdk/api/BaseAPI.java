package cmcc.iot.onenet.studio.javasdk.api;

import cmcc.iot.onenet.studio.javasdk.exception.OnenetStudioApiException;
import cmcc.iot.onenet.studio.javasdk.http.BaseResponse;
import cmcc.iot.onenet.studio.javasdk.http.HttpPostMethod;
import cmcc.iot.onenet.studio.javasdk.http.RequestInfo;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

public  class BaseAPI {
    public HttpPostMethod HttpMethod = new HttpPostMethod(RequestInfo.Method.POST);

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    public void setParam(String topic, String protocol, String id, String version, Object param, String token,String url){
        Map<String, Object> headMap = new HashMap<String, Object>();
        headMap.put("token",token);
        HttpMethod.setHeader(headMap);
        // 路径参数
        Map<String, Object> urlMap = new HashMap<String, Object>();
        urlMap.put("topic",topic);
        if(StringUtils.isNotBlank(protocol)){
            urlMap.put("protocol",protocol);
        }
        // body参数
        Map<String, Object> bodyMap = new HashMap<String, Object>();
        if(StringUtils.isNotBlank(id)){
            bodyMap.put("id",id);
        }
        if(StringUtils.isNotBlank(version)){
            bodyMap.put("version",version);
        }
        bodyMap.put("params",param);
        String json=null;
        ObjectMapper reMapper = new ObjectMapper();
        try {
            json = reMapper.writeValueAsString(bodyMap);
        } catch (Exception e) {
            logger.error("json error", e.getMessage());
            throw new OnenetStudioApiException(e.getMessage());
        }
        logger.info("body:" + json);
        ((HttpPostMethod)HttpMethod).setEntity(json);
        HttpMethod.setcompleteUrl(url,urlMap);
    }

    public BaseResponse executeApi(){
        ObjectMapper mapper = new ObjectMapper();
        BaseResponse response=null;
        try {
            HttpResponse httpResponse=HttpMethod.execute();
            response = mapper.readValue(httpResponse.getEntity().getContent(),BaseResponse.class);
            return response;

        } catch (Exception e) {
            logger.error("json error {}", e.getMessage());
            throw new OnenetStudioApiException(e.getMessage());
        }finally {
            try {
                HttpMethod.httpClient.close();
            } catch (Exception e) {
                logger.error("http close error: {}", e.getMessage());
                throw new OnenetStudioApiException(e.getMessage());
            }
        }

    }
}
