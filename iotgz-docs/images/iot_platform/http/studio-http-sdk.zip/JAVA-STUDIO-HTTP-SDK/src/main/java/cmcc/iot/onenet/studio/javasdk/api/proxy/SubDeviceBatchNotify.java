package cmcc.iot.onenet.studio.javasdk.api.proxy;

import cmcc.iot.onenet.studio.javasdk.api.BaseAPI;
import cmcc.iot.onenet.studio.javasdk.utils.Config;

public class SubDeviceBatchNotify extends BaseAPI {

    public void subDeviceBatchNotify(String pid, String deviceName, String protocol, String id, String version, Object param, String token){
        String url = Config.getString("test.url")+ "/proxy/device/thing/pack/post";
        String topic  = "$sys/" + pid + "/" + deviceName + "/thing/pack/post";
        super.setParam(topic,protocol,id,version,param,token,url);
    }
}
