package cmcc.iot.onenet.studio.javasdk.api.proxy;

import cmcc.iot.onenet.studio.javasdk.api.BaseAPI;
import cmcc.iot.onenet.studio.javasdk.utils.Config;

public class SubDeviceLogout extends BaseAPI {

    public void subDeviceLogout(String pid, String deviceName, String protocol, String id, String version, Object param, String token){
        String url = Config.getString("test.url")+ "/proxy/device/thing/logout";
        String topic  = "$sys/" + pid + "/" + deviceName + "/thing/sub/logout";
        super.setParam(topic,protocol,id,version,param,token,url);
    }
}
