package cmcc.iot.onenet.studio.javasdk.dto;

public class Property {
    public Object value;
    public Long time;

    public Property(Object value, Long time) {
        this.value = value;
        this.time = time;
    }

    public Property() {
    }

    public Object getValue() {
        return value;
    }

    public void setValue(Object value) {
        this.value = value;
    }

    public Long getTime() {
        return time;
    }

    public void setTime(Long time) {
        this.time = time;
    }
}
