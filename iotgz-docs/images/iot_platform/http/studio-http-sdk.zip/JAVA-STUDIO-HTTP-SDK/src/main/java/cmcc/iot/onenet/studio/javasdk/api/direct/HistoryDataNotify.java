package cmcc.iot.onenet.studio.javasdk.api.direct;

import cmcc.iot.onenet.studio.javasdk.api.BaseAPI;
import cmcc.iot.onenet.studio.javasdk.utils.Config;


public class HistoryDataNotify extends BaseAPI {

    public void historyDataNotify(String pid, String deviceName, String protocol, String id, String version, Object param, String token){
        String url = Config.getString("test.url")+ "/device/thing/history/post";
        String topic  = "$sys/" + pid + "/" + deviceName + "/thing/history/post";
        super.setParam(topic,protocol,id,version,param,token,url);
    }
}
