package cmcc.iot.onenet.studio.javasdk.api.direct;

import cmcc.iot.onenet.studio.javasdk.api.BaseAPI;
import cmcc.iot.onenet.studio.javasdk.utils.Config;

import java.util.Map;

public class DeviceEventNotify extends BaseAPI {

    public void deviceEventNotify(String pid, String deviceName, String protocol, String id, String version, Map<String, Object> param, String token){
        String url = Config.getString("test.url")+ "/device/thing/event/post";
        String topic  = "$sys/" + pid + "/" + deviceName + "/thing/event/post";
        super.setParam(topic,protocol,id,version,param,token,url);
    }
}
