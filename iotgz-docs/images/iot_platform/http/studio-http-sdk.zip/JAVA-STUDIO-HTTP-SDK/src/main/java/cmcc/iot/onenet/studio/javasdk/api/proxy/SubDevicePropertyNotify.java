package cmcc.iot.onenet.studio.javasdk.api.proxy;

import cmcc.iot.onenet.studio.javasdk.api.BaseAPI;
import cmcc.iot.onenet.studio.javasdk.utils.Config;

import java.util.Map;

public class SubDevicePropertyNotify extends BaseAPI {

    public void subDevicePropertyNotify(String pid, String deviceName, String protocol, String id, String version, Object param, String token){
        String url = Config.getString("test.url")+ "/proxy/device/thing/pack/post";
        String topic  = "$sys/" + pid + "/" + deviceName + "/thing/pack/post";
        super.setParam(topic,protocol,id,version,param,token,url);
    }
}
