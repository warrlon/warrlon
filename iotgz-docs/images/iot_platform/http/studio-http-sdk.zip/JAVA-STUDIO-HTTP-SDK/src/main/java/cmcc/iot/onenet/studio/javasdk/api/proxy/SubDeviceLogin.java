package cmcc.iot.onenet.studio.javasdk.api.proxy;

import cmcc.iot.onenet.studio.javasdk.api.BaseAPI;
import cmcc.iot.onenet.studio.javasdk.utils.Config;

public class SubDeviceLogin extends BaseAPI {

    public void subDeviceLogin(String pid, String deviceName, String protocol, String id, String version, Object param, String token){
        String url = Config.getString("test.url")+ "/proxy/device/thing/login";
        String topic  = "$sys/" + pid + "/" + deviceName + "/thing/sub/login";
        super.setParam(topic,protocol,id,version,param,token,url);
    }
}
