package com.cmiot.gateway.exceptions;

/**
 * 配置非法异常
 */
public final class IllegalConfigException extends RuntimeException {

    public IllegalConfigException(String msg) {
        super(msg);
    }

    @Override
    public void printStackTrace() {
    }
}
