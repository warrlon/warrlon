package com.cmiot.gateway.entity;


/**
 * 设备与协议网关服务建立连接的协议站类型
 */
public enum ProtocolType {
    /**
     * TCP
     */
    TCP,
}
