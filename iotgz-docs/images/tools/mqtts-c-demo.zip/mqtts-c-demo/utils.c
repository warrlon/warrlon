#include <openssl/hmac.h>
#include <openssl/pem.h>
#include <openssl/bio.h>
#include <openssl/evp.h>
#include <string.h>

int base64_encode(const unsigned char *in, int in_len, char *out) {
    BIO *bio, *b64;
    BUF_MEM *buf;

    b64 = BIO_new(BIO_f_base64());
    if (!b64) {
        return -1;
    }

    bio = BIO_new(BIO_s_mem());
    if (!bio) {
        BIO_free_all(b64);
        return -1;
    }

    bio = BIO_push(b64, bio);

    //Ignore newlines - write everything in one line
    BIO_set_flags(bio, BIO_FLAGS_BASE64_NO_NL);
    BIO_write(bio,in, in_len);
    BIO_flush(bio);
    BIO_get_mem_ptr(bio, &buf);

    strncpy(out,buf->data,buf->length);
    BIO_free_all(bio);

    return 0;
}

int calc_base64_decode_length(const char* b64txt, int len) {
    int padding = 0;

    if ('=' == b64txt[len - 1] && '=' == b64txt[len - 2])
        padding = 2;
    else if ('=' == b64txt[len-1]) //last char is =
        padding = 1;

    return (len * 3) / 4 - padding;
}


int base64_decode(const char *in,int in_len, unsigned char *output) {
    BIO *bio = BIO_new_mem_buf(in, -1);
    BIO *b64 = BIO_new(BIO_f_base64());
    bio = BIO_push(b64, bio);

    //Do not use newlines to flush buffer
    BIO_set_flags(bio, BIO_FLAGS_BASE64_NO_NL);

    size_t dec_len = calc_base64_decode_length(in, in_len);

    if (BIO_read(bio, output,dec_len) != dec_len)
        return -1;

    BIO_free_all(bio);
    return 0;
}


int hmac_sha1(const unsigned char *input,int input_len,
              const unsigned char *key,int key_len,unsigned char *output) {
    if(NULL == input || 0 == input_len)
        return -1;

    unsigned int output_len = 0;

    HMAC(EVP_sha1(), key, key_len, input, input_len, output, &output_len);

    return output_len;
}

int url_encode(const char *input,int input_len,char *output,const int output_len) {
    static unsigned char hexchars[] = "0123456789ABCDEF";
    int i, j;
    char ch;

    if(input_len < 0 || output_len < 0)
        return -1;

    for(i = 0, j = 0; i < input_len && j < output_len; i++) {
        ch = *(input + i);
        if((ch >= 'A' && ch <= 'Z') ||
                (ch >= 'a' && ch <= 'z') ||
                (ch >= '0' && ch <= '9') ||
                ch == '.' || ch == '-' || ch == '*' || ch == '_')
            output[j++] = ch;
        else if(ch == ' ')
            output[j++] = '+';
        else {
            if(j + 3 <= output_len) {
                output[j++] = '%';
                output[j++] = hexchars[(unsigned char)ch >> 4];
                output[j++] = hexchars[(unsigned char)ch & 0xF];
            } else {
                return -2;
            }
        }
    }

    if(i == 0)
        return 0;
    else if(i == input_len)
        return j;
    return -2;
}
