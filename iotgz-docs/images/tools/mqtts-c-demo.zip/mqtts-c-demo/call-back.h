#ifndef CALL_BACK_H_
#define CALL_BACK_H_

#include <MQTTClient.h>

/**
 * @brief 收到publish消息时的回调
 *
 * @param context
 * @param topicName
 * @param topicLen
 * @param m
 *
 * @return
 */
int mqtts_on_message_arrived(void *context, char *topic_name,
                             int topic_len, MQTTClient_message *message);


/**
 * @brief
 *
 * @param context
 * @param dt
 */
void mqtts_on_message_delivered(void *context, MQTTClient_deliveryToken dt);

/**
 * @brief 设备断线处理逻辑
 *
 * @param context
 * @param cause
 */
void mqtts_connection_lost(void *context,char *cause);
#endif
