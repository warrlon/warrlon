#ifndef TYPES_H_
#define TYPES_H_

const char *base_subscribe_topic;
const char *base_dp_upload_topic;
const char *base_cmd_response_topic;

const char* base_dp_str;

#endif
