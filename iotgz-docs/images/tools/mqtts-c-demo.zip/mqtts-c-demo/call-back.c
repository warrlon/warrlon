#include <MQTTClient.h>
#include <unistd.h>
#include <stdlib.h>
#include "call-back.h"
#include "mqtts-client.h"

/**
 * @brief 处理dp相应
 *
 * @param mqtts_client
 * @param topic_name
 * @param payload
 * @param payload_len
 */
static void handle_dp_response(mqtts_client_t *mqtts_client,const char *topic_name,
                               void *payload, int payload_len);
/**
 * @brief 处理和cmd相关的报文
 *
 * @param mqtts_client
 * @param topic_name
 * @param payload
 * @param payload_len
 */
static void handle_cmd(mqtts_client_t *mqtts_client,const char *topic_name,
                       void *payload, int payload_len);

/**
 * @brief 处理平台下发的命令
 *
 * @param mqtts_client
 * @param topic_name
 * @param payload
 * @param payload_len
 */
static void handle_cmd_request(mqtts_client_t *mqtts_client,const char *topic_name,
                               void *payload, int payload_len);

/**
 * @brief 设备回复命令后处理平台的响应
 *
 * @param mqtts_client
 * @param topic_name
 * @param payload
 * @param payload_len
 */
static void handle_cmd_response(mqtts_client_t *mqtts_client,const char *topic_name,
                                void *payload, int payload_len);
volatile MQTTClient_deliveryToken deliveredtoken;

void mqtts_connection_lost(void *context,char *cause) {
    mqtts_client_t *mqtts_client = (mqtts_client_t *) context;
    mqtts_client->connected = 0;
    mqtts_client->subscribed = 0;

    //start reconnect
    MQTTClient_connectOptions opts = MQTTClient_connectOptions_initializer;
    MQTTClient_SSLOptions sslopts = MQTTClient_SSLOptions_initializer;
    int rc = 0;

    mqtts_client->connected = 0;
    if(NULL != cause) {
        printf("[connection] pid[%s],devcice_name[%s] connection lost,cause[%s]\n",
               mqtts_client->user_name, mqtts_client->client_id,cause);
    } else {
        printf("[connection] pid[%s],devcice_name[%s] connection lost...\n",
               mqtts_client->user_name, mqtts_client->client_id);

    }

    opts.keepAliveInterval = 60;
    opts.cleansession = 1;
    opts.username = mqtts_client->user_name;
    opts.password = mqtts_client->password;

    opts.will = NULL;

    opts.ssl = &sslopts;
    if (NULL != mqtts_client->ca_file)
        opts.ssl->trustStore = mqtts_client->ca_file;

    printf("[connection] start reconnect in 5 seconds...\n");
    usleep(1000 * 1000 * 5);

    while(1) {
        if ((rc = MQTTClient_connect(*(mqtts_client->mqtt_client), &opts)) != MQTTREASONCODE_SUCCESS) {
            printf("[connection] start reconnect in 5 seconds...\n");
            usleep(1000 * 1000 * 3);
            continue;
        }
        mqtts_client->connected = 1;
        break;
    }
}
int mqtts_on_message_arrived(void *context, char *topic_name,
                             int topic_len, MQTTClient_message *message) {

    mqtts_client_t *mqtts_client = (mqtts_client_t *) context;

    /*目前只处理dp和cmd*/
    char *dp_pos = NULL;
    char *cmd_pos = NULL;
    /*printf("receive publish message,topic[%s]\n",topic_name);*/

    /*目前简单处理,实际中应按/分割topic然后做校验*/
    dp_pos = strstr(topic_name,"/dp/post/json/");
    if(NULL != dp_pos) {
        handle_dp_response(mqtts_client,topic_name,message->payload,message->payloadlen);
    }

    /*目前简单处理,实际中应按/分割topic然后做校验*/
    cmd_pos = strstr(topic_name,"/cmd/");
    if(NULL != cmd_pos) {
        handle_cmd(mqtts_client,topic_name,message->payload,message->payloadlen);
    }


    MQTTClient_freeMessage(&message);
    MQTTClient_free(topic_name);

    /*当下行报文处理完成后必须返回非0值(true)*/
    return 1;
}

void mqtts_on_message_delivered(void *context, MQTTClient_deliveryToken dt) {
    printf("message with token value %d delivery confirmed\n", dt);
    deliveredtoken = dt;
}

static void handle_dp_response(mqtts_client_t *mqtts_client,const char *topic_name,
                               void *payload, int payload_len) {
    char *accepted_pos = NULL;
    char *rejected_pos = NULL;
    accepted_pos = strstr(topic_name,"/accepted");
    if(NULL != accepted_pos) {
        printf("[datapoint] receive dp accepted response from OneNET...\n");
        return;
    }

    rejected_pos = strstr(topic_name,"/rejected");
    if(NULL != rejected_pos) {
        char *err_msg = (char *)malloc(payload_len * sizeof(char) + 1);
        if(NULL == err_msg) {
            return;
        }
        memset(err_msg,'\0',payload_len + 1);
        strncpy(err_msg,(const char*)payload,payload_len);

        printf("[datapoint] receive dp rejected response from OneNET,err_msg[%s]\n",err_msg);

        free(err_msg);
        return;
    }
    printf("[datapoint] unknown dp response topic[%s]\n",topic_name);
}

static void handle_cmd(mqtts_client_t *mqtts_client,const char *topic_name,
                       void *payload, int payload_len) {
    char *cmd_pos = NULL;
    cmd_pos = strstr(topic_name,"/cmd/request/");

    if(NULL != cmd_pos) {
        handle_cmd_request(mqtts_client,topic_name,payload,payload_len);
    } else {
        handle_cmd_response(mqtts_client,topic_name,payload,payload_len);
    }
}

static void handle_cmd_request(mqtts_client_t *mqtts_client,const char *topic_name,
                               void *payload, int payload_len) {

    const char *part_of_cmd_request_topic = "/cmd/request/";
    int part_of_cmd_request_topic_len = strlen(part_of_cmd_request_topic);
    char *cmd_pos = strstr(topic_name,part_of_cmd_request_topic);

    if(NULL != cmd_pos) {
        MQTTClient_deliveryToken token;
        MQTTClient_message pubmsg = MQTTClient_message_initializer;

        /*topic格式为$sys/{pid}/{authInfo}/cmd/response/{cmd_uudi}*/
        char cmd_response_topic[512] = {'\0'};

        /*回复给平台的内容*/
        char *cmd_response_content = "receive cmd...";
        int rc = 0;
        int i = 0;

        char *tmp = payload;

        printf("[cmd] receive cmd from OneNET\n\tcmduuid:%s\n\tpayload:",cmd_pos + part_of_cmd_request_topic_len);

        for(i = 0; i < payload_len; i++) {
            printf("%02X ",(unsigned char)tmp[i]);
        }
        printf("\n");

        /*回复该命令*/
        snprintf(cmd_response_topic,sizeof(cmd_response_topic), base_cmd_response_topic,
                 mqtts_client->user_name,
                 mqtts_client->client_id,
                 cmd_pos + part_of_cmd_request_topic_len);

        pubmsg.payload = cmd_response_content;
        pubmsg.payloadlen = strlen(cmd_response_content);
        pubmsg.qos = 0;
        pubmsg.retained = 0;

        if ((rc = MQTTClient_publishMessage(*(mqtts_client->mqtt_client), cmd_response_topic, &pubmsg, &token)) != MQTTREASONCODE_SUCCESS) {
            printf("failed to start publish message, return code %d\n", rc);
        }
        MQTTClient_waitForCompletion(*(mqtts_client->mqtt_client), token, 10000L);
    }

}
static void handle_cmd_response(mqtts_client_t *mqtts_client,const char *topic_name,
                                void *payload, int payload_len) {
    char *response_accepted_pos = NULL;
    char *response_rejected_pos = NULL;
    char *tmp = NULL;;
    const char *part_of_cmd_response_topic = "/cmd/response/";
    int part_of_cmd_response_topic_len = strlen(part_of_cmd_response_topic);


    tmp = strstr(topic_name,part_of_cmd_response_topic);
    if(NULL != tmp) {
        response_accepted_pos = strstr(tmp,"/accepted");
        if(NULL != response_accepted_pos) {

            /*得到cmduuid的起始位置*/
            char *cmd_uuid = (char *)malloc(response_accepted_pos - tmp - part_of_cmd_response_topic_len + 1);
            if(NULL == cmd_uuid) {
                return;
            }
            memset(cmd_uuid,'\0',response_accepted_pos - tmp - part_of_cmd_response_topic_len + 1);
            strncpy(cmd_uuid,tmp + part_of_cmd_response_topic_len,response_accepted_pos - tmp - part_of_cmd_response_topic_len);

            printf("[cmd] OneNET accept the cmd[%s] response...\n",cmd_uuid);
            free(cmd_uuid);
            return;
        }

        response_rejected_pos = strstr(tmp,"/rejected");
        if(NULL != response_rejected_pos) {

            /*得到cmduuid的起始位置*/
            char *cmd_uuid = (char *)malloc(response_rejected_pos - tmp - part_of_cmd_response_topic_len + 1);
            if(NULL == cmd_uuid) {
                return;
            }
            memset(cmd_uuid,'\0',response_rejected_pos - tmp - part_of_cmd_response_topic_len + 1);
            strncpy(cmd_uuid,tmp + part_of_cmd_response_topic_len,response_rejected_pos - tmp - part_of_cmd_response_topic_len);
            printf("[cmd] OneNET reject the cmd[%s] response...\n",cmd_uuid);

            free(cmd_uuid);
            return;
        }
        return;
    }
    printf("[cmd] unknown cmd response topic\n");
}
