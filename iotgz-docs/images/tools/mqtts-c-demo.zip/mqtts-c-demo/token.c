#include <openssl/hmac.h>
#include <stdlib.h>
#include <stdio.h>
#include "token.h"
#include "utils.h"

/*SasToken中res字段中的products常量*/
static const char *PRODUCTS = "products";

/*SasToken中res字段中的devices常量*/
static const char *DEVICES = "devices";

/*本demo中使用sha1签名算法, MQTTs支持MD5、sha1、sha256签名算法*/
static const char *SHA1 = "sha1";

/*SasToken中res字段format,用于格式化res字段*/
static const char *RESOURCE_FMT = "products/%s/devices/%s";

/*SasToken的format,用于格式化整个SasToken*/
static const char *SAS_TOKEN_FMT = "version=%s&res=%s&et=%s&method=%s&sign=%s";

/*用于计算SasToken签名的加密字符串：et + \n + method + \n + res + \n + version*/
static const char *ENCRYPT_DATA_FMT = "%s\n%s\n%s\n%s";

/*
 * SasToken中常量字符串的总长度
 * strlen("version=") + strlen("&res=") + strlen("&et=") + strlen("&method=") + strlen("&sign=")
 * 8 + 5 + 4 + 8 + 6 = 31
 */
static const int SAS_TOKEN_CONST_LEN = 31;

/**
 * @brief 对resource字段进行url编码
 *
 * @param pid         设备的产品id
 * @param device_name 设备名称
 *
 * @return		      url编码后的resource
 */
static char *url_encode_resource(const char *pid, const char *device_name);

/**
 * @brief 组装生成token 的encrypt data
 *
 * @param expire_time token过期时间(到什么时刻过期)
 * @param pid 产品id
 * @param device_name 设备名称
 * @param version token使用的版本
 * @param device_access_key 设备级access key
 *
 * @return
 */
static char *assemble_encrypt_data(const char *expire_time,
                                   const char *pid,
                                   const char *device_name,
                                   const char *version,
                                   const char *device_access_key);

/**
 * @brief 生成SasToken签名字段
 * encrypt_data: expire_time + "\n" + sha1 + "\n" + "products/{pid}/devices/{device_name}" + "\n" + version
 *
 * @param encrypt_data	    用于计算签名的加密字符串
 * @param encrypt_data_len  用于计算签名的加密字符串长度
 * @param device_access_key 设备级的access key
 *
 * @return token中的签名字段
 */
static char *generate_token_sign(const char *encrypt_data,
                                 int encrypt_data_len,
                                 const char *device_access_key);

/**
 * @brief 组装整个SasToken
 *
 * @param version               Token所使用的版本(目前固定为2018-10-31)
 * @param url_encoded_resource  经过url编码后的resource
 * @param expire_time           Token的超时时间(单位为s)
 * @param method                Token所使用的签名算法
 * @param url_encoded_sign      经过url编码后的签名
 *
 * @return 完整的SasToken
 */
static char *assemble_auth_token(const char *version,
                                 const char *url_encoded_resource,
                                 const char *expire_time,
                                 const char *method,
                                 const char *url_encoded_sign);

static char *assemble_encrypt_data(const char *expire_time,
                                   const char *pid,
                                   const char *device_name,
                                   const char *version,
                                   const char *device_access_key) {

    char *encrypt_data = NULL;
    int encrypt_data_len = 0;

    int expire_time_len = strlen(expire_time);
    int method_len = strlen(SHA1);
    int version_len = strlen(version);

    int products_constant_string_len = strlen(PRODUCTS);
    int devices_constant_string_len = strlen(DEVICES);
    int pid_len = strlen(pid);
    int device_name_len = strlen(device_name);

    int resource_len = products_constant_string_len + 1 + pid_len + 1 + devices_constant_string_len + 1 + device_name_len;
    char *resource = (char *)malloc(resource_len + 1);
    if(NULL == resource) {
        return NULL;
    }

    memset(resource, '\0', resource_len + 1);
    snprintf(resource, resource_len + 1, RESOURCE_FMT, pid, device_name);

    /*3 \n*/
    encrypt_data_len += 3;
    encrypt_data_len += expire_time_len;
    encrypt_data_len += method_len;
    encrypt_data_len += version_len;
    encrypt_data_len += resource_len;

    encrypt_data = (char *)malloc(encrypt_data_len + 1);
    if(NULL == encrypt_data) {
        free(resource);
        return NULL;
    }

    memset(encrypt_data, '\0', encrypt_data_len + 1);

    snprintf(encrypt_data, encrypt_data_len + 1, ENCRYPT_DATA_FMT,
             expire_time,
             SHA1,
             resource,
             version);

    free(resource);
    resource = NULL;

    return encrypt_data;
}

static char *generate_token_sign(const char *encrypt_data,
                                 int encrypt_data_len,
                                 const char *device_access_key) {

    int decrypted_device_access_key_len = 0;
    unsigned char *decrypted_device_access_key = NULL;

    int rc = 0;

    unsigned char sha1[EVP_MAX_MD_SIZE] = {'\0'};

    /*数据经过base64编码后长度最多为origin_len * 4/3 + 2*/
    int sign_len = (int)(EVP_MAX_MD_SIZE * 4 / 3) + 2;
    char *sign = NULL;

    if(NULL == encrypt_data || 0 == encrypt_data_len)
        return NULL;

    sign = (char *)malloc(sign_len + 1);
    if(NULL == sign) {
        return NULL;
    }

    memset(sign, '\0', sign_len + 1);

    decrypted_device_access_key_len = calc_base64_decode_length(device_access_key, strlen(device_access_key));
    decrypted_device_access_key = (unsigned char*) malloc(decrypted_device_access_key_len);
    if(NULL == decrypted_device_access_key) {
        free(sign);
        return NULL;
    }

    memset(decrypted_device_access_key, '\0', decrypted_device_access_key_len);

    /*base64解码device_access_key*/
    rc = base64_decode(device_access_key, strlen(device_access_key), decrypted_device_access_key);
    if(0 != rc) {
        free(sign);
        return NULL;
    }

    /*得到二进制的sha1值*/
    rc = hmac_sha1((const unsigned char*)encrypt_data,
                   encrypt_data_len,
                   decrypted_device_access_key,
                   decrypted_device_access_key_len,
                   sha1);

    if(rc <= 0) {
        free(sign);
        free(decrypted_device_access_key);
        return NULL;
    }

    /*将二进制的sha1用base64编码*/
    rc = base64_encode(sha1, rc, sign);
    if(0 != rc) {
        free(sign);
        free(decrypted_device_access_key);
        return NULL;
    }

    free(decrypted_device_access_key);

    return sign;
}

char *generate_auth_token(int64_t expire_time,
                          const char *pid,
                          const char *device_name,
                          const char *version,
                          const char *device_access_key) {
    char expire_time_str[64] = {'\0'};

    /*组装用于计算sign的加密字符串*/
    int encrypt_data_len = 0;
    char *encrypt_data = NULL;

    /*用于计算签名*/
    char *sign = NULL;
    int	sign_len = 0;

    int url_encoded_sign_len = 0;
    char *url_encoded_sign = NULL;

    int rc = 0;

    /*url编码resource字段*/
    char *url_encoded_resource = NULL;

    /*完整的SasToken*/
    char *completed_auth_token = NULL;

    if(0 == expire_time
            || NULL == pid || NULL == device_name
            || NULL == version || NULL == device_access_key)
        return NULL;

    /*格式化Token过期时间，从int64转换为字符串*/
    snprintf(expire_time_str, sizeof(expire_time_str),"%ld", expire_time);

    /*组装用于计算Token签名的加密数据*/
    encrypt_data = assemble_encrypt_data(expire_time_str, pid, device_name, version, device_access_key);
    if(NULL == encrypt_data)
        return NULL;

    encrypt_data_len = strlen(encrypt_data);

    /*计算SasToken签名*/
    sign = generate_token_sign(encrypt_data, encrypt_data_len, device_access_key);
    if(NULL == sign) {
        free(encrypt_data);
        return NULL;
    }

    sign_len = strlen(sign);
    url_encoded_sign_len = sign_len * 3;

    /*分配用于url编码的签名字符串的空间*/
    url_encoded_sign = (char *)malloc(url_encoded_sign_len + 1);
    if(NULL == url_encoded_sign) {
        free(encrypt_data);
        free(sign);
        return NULL;
    }

    memset(url_encoded_sign,'\0', url_encoded_sign_len + 1);

    /*获取url编码后的sign*/
    rc = url_encode(sign, sign_len, url_encoded_sign, url_encoded_sign_len + 1);
    if(rc < 0) {
        free(encrypt_data);
        free(sign);
        free(url_encoded_sign);
        return NULL;
    }

    /*获取url编码后的resource*/
    url_encoded_resource = url_encode_resource(pid, device_name);
    if(NULL == url_encoded_resource) {
        free(encrypt_data);
        free(sign);
        free(url_encoded_sign);
        return NULL;
    }

    /*组装SasToken*/
    completed_auth_token = assemble_auth_token(version, url_encoded_resource, expire_time_str, SHA1, url_encoded_sign);
    if(NULL == completed_auth_token) {
        free(encrypt_data);
        free(sign);
        free(url_encoded_sign);
        free(url_encoded_resource);
        return NULL;
    }

    free(encrypt_data);
    free(sign);
    free(url_encoded_sign);
    free(url_encoded_resource);

    return completed_auth_token;
}


static char *url_encode_resource(const char *pid, const char *device_name) {
    int products_constant_string_len = strlen(PRODUCTS);
    int devices_constant_string_len = strlen(DEVICES);
    int pid_len = strlen(pid);
    int device_name_len = strlen(device_name);

    int resource_len = products_constant_string_len + 1 + pid_len + 1 + devices_constant_string_len + 1 + device_name_len;

    /*经过url编码后的数据最多为源数据的3倍*/
    int url_encoded_resource_len = resource_len * 3;

    char *resource = NULL;
    char *url_encoded_resource = NULL;

    int url_encode_resource_rc = 0;

    /* res = products/{pid}/devices{device_name} */
    resource = (char *)malloc(resource_len + 1);
    if(NULL == resource) {
        return NULL;
    }

    memset(resource,'\0', resource_len + 1);

    /*格式化为products/{pid}/devices{device_name}*/
    snprintf(resource, resource_len + 1, RESOURCE_FMT, pid, device_name);

    /*分配url编码后的resource空间*/
    url_encoded_resource = (char *)malloc(url_encoded_resource_len + 1);
    if(NULL == url_encoded_resource) {
        free(resource);
        resource = NULL;
        return NULL;
    }

    memset(url_encoded_resource, '\0', url_encoded_resource_len);

    /*对resource进行url编码*/
    url_encode_resource_rc = url_encode(resource, resource_len, url_encoded_resource,  url_encoded_resource_len + 1);
    if(url_encode_resource_rc < 0) {
        free(resource);
        free(url_encoded_resource);
        return NULL;
    }

    free(resource);
    resource = NULL;

    return url_encoded_resource;
}
static char *assemble_auth_token(const char *version,
                                 const char *url_encoded_resource,
                                 const char *expire_time,
                                 const char *method,
                                 const char *url_encoded_sign) {

    int version_len = strlen(version);
    int url_encoded_resource_len = strlen(url_encoded_resource);
    int expire_time_len = strlen(expire_time);
    int method_len = strlen(method);
    int url_encoded_sign_len = strlen(url_encoded_sign);

    int total_token_len = 0;

    char *completed_auth_token = NULL;

    total_token_len += SAS_TOKEN_CONST_LEN;
    total_token_len += version_len;
    total_token_len += url_encoded_resource_len;
    total_token_len += expire_time_len;
    total_token_len += method_len;
    total_token_len += url_encoded_sign_len;;

    completed_auth_token = (char *)malloc(total_token_len + 1);
    if(NULL == completed_auth_token) {
        return NULL;
    }

    memset(completed_auth_token, '\0', total_token_len + 1);

    snprintf(completed_auth_token, total_token_len + 1, SAS_TOKEN_FMT,
             version,
             url_encoded_resource,
             expire_time,
             method,
             url_encoded_sign);

    return completed_auth_token;
}
