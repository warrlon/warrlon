#ifndef UTILS_H_
#define UTILS_H_
/**
 * @file utils.h
 * @brief
 * @author wangxiaojun
 * @version 0.1
 * @date 2019-07-20
 */

/**
 * @brief base64 encode
 *
 * 需保证output空间足够
 * @param in
 * @param in_len
 * @param out
 *
 * @return
 */
int base64_encode(const unsigned char *in, int in_len, char *out);

/**
 * @brief base decode
 *
 * 需保证output空间足够
 * @param in
 * @param in_len
 * @param output
 *
 * @return
 */
int base64_decode(const char *in,int in_len, unsigned char *output);
/**
 * @brief hamc_sha1 签名
 *
 * 需保证output空间足够
 * @param input
 * @param input_len
 * @param key
 * @param key_len
 * @param output
 *
 * @return
 */
int hmac_sha1(const unsigned char *input,int input_len,
              const unsigned char *key,int key_len,
              unsigned char *output);

/**
 * @brief 计算base64 decode后的长度
 *
 * @param b64txt
 * @param len
 *
 * @return
 */
int calc_base64_decode_length(const char* b64txt, int len);



int url_encode(const char *input,int input_len,char *output,const int output_len);
#endif
