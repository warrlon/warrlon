#ifndef MQTTS_CLIENT_H_
#define MQTTS_CLIENT_H_

#include <string.h>
#include <stdint.h>
#include <MQTTClient.h>
#include "types.h"

struct mqtts_client_t {
    MQTTClient *mqtt_client;
    char *client_id;
    char *user_name;
    char *password;
    char *ca_file;
    volatile int connected;
    volatile int subscribed;
};


typedef struct mqtts_client_t mqtts_client_t;


/**
 * @brief 创建MQTTS CLIENT实例
 *
 * @param client_id 设备名称
 * @param user_name 产品id
 * @param access_key 设备级access key
 * @param ca_file   OneNET MQTTS证书路径
 *
 * @return
 */
mqtts_client_t *create_mqtts_client(const char *client_id,const char *user_name,
                                    const char *device_access_key,int64_t expire_time,
                                    const char *version,const char *ca_file);


/**
 * @brief  连接至OneNET
 *
 * @param mqtts_client
 *
 * @return
 */
int connect_to_onenet(mqtts_client_t *mqtts_client,const char *server_url);

/**
 * @brief  订阅
 *
 * @param mqtts_client
 *
 * @return
 */
int subscribe(mqtts_client_t *mqtts_client,const char *topic);


/**
 * @brief 断开连接
 *
 * @param mqtts_client
 *
 * @return
 */
int disconnect(mqtts_client_t *mqtts_client);


/**
 * @brief 发送随机数据点
 *
 * @param mqtts_client
 *
 * @return
 */
int send_random_dp(mqtts_client_t *mqtts_client);

/**
 * @brief 销毁MQTTS CLIENT 实例
 *
 * @param client
 */
void destroy_mqtts_client(mqtts_client_t *client);
#endif
