#include "busi.h"
#include <string.h>
#include <unistd.h>

extern volatile int run;
void busi_loop(mqtts_client_t *mqtts_client) {
    char topic[512] = {'\0'};
    snprintf(topic,sizeof(topic),base_subscribe_topic,
             mqtts_client->user_name,mqtts_client->client_id);

    while(run) {
        if(mqtts_client->connected) {
            if(!mqtts_client->subscribed) {
                int rc = subscribe(mqtts_client,topic);
                if(MQTTREASONCODE_GRANTED_QOS_0 == rc) {
                    printf("[subscription] subscribe topic[%s] success...\n",topic);
                    mqtts_client->subscribed = 1;
                } else {
                    printf("[subscription] subscribe topic[%s] failed...\n",topic);
                    mqtts_client->subscribed = 0;
                }
            }
            send_random_dp(mqtts_client);
        }
        usleep(1000 * 1000 *5);
    }
}
