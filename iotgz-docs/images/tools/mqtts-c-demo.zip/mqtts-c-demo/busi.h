#ifndef BUSI_H_
#define BUSI_H_

#include "mqtts-client.h"

/**
 * @brief 设备主循环
 *
 * @param mqtts_client
 */
void busi_loop(mqtts_client_t *mqtts_client);

#endif
