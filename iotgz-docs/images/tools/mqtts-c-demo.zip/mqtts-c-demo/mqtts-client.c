#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "mqtts-client.h"
#include "call-back.h"
#include "token.h"


mqtts_client_t *create_mqtts_client(const char *client_id,const char *user_name,
                                    const char *device_access_key,int64_t expire_time,
                                    const char *version,const char *ca_file) {

    char *token = NULL;
    MQTTClient *mqtt_client = NULL;
    mqtts_client_t *client = NULL;

    if(NULL == client_id || NULL == user_name ||
            NULL == device_access_key || 0 == expire_time ||
            NULL == version || NULL == ca_file) {
        return NULL;
    }

    mqtt_client = (MQTTClient *)malloc(sizeof(MQTTClient));
    if(NULL == mqtt_client) {
        return NULL;
    }

    client = (mqtts_client_t*)malloc(sizeof(mqtts_client_t));
    if(NULL == client) {
        free(mqtt_client);
        return NULL;
    }


    /*用device access key计算鉴权用的token*/
    token = generate_auth_token(expire_time,user_name,client_id,version,device_access_key);

    if(NULL == token) {
        free(mqtt_client);
        free(client);
        return NULL;
    }


    client->mqtt_client = mqtt_client;
    client->client_id = strdup(client_id);
    client->user_name = strdup(user_name);

    /*不需要用strdup*/
    client->password = token;
    client->ca_file = strdup(ca_file);

    client->connected = 0;
    client->subscribed = 0;
    return client;
}

void destroy_mqtts_client(mqtts_client_t *client) {
    if(NULL == client)
        return;

    free(client->client_id);
    free(client->user_name);
    free(client->password);
    MQTTClient_destroy(client->mqtt_client);
    free(client->mqtt_client);
    free(client->ca_file);
    free(client);

    client = NULL;
}
int connect_to_onenet(mqtts_client_t *mqtts_client,const char *server_url) {
    MQTTClient_connectOptions opts = MQTTClient_connectOptions_initializer;
    MQTTClient_SSLOptions sslopts = MQTTClient_SSLOptions_initializer;

    int rc = MQTTClient_create(mqtts_client->mqtt_client,server_url,mqtts_client->client_id,MQTTCLIENT_PERSISTENCE_NONE, NULL);
    if(0 != rc) {
        return rc;
    }


    rc = MQTTClient_setCallbacks(*(mqtts_client->mqtt_client), mqtts_client,
                                 mqtts_connection_lost,
                                 mqtts_on_message_arrived,
                                 mqtts_on_message_delivered);
    if(0 != rc) {
        return rc;
    }

    opts.keepAliveInterval = 60;

    /*使用MQTT 3.1.1版本*/
    opts.MQTTVersion = MQTTVERSION_3_1_1;
    opts.cleansession = 1;
    opts.username = mqtts_client->user_name;
    opts.password = mqtts_client->password;

    opts.will = NULL;

    opts.ssl = &sslopts;
    if (NULL != mqtts_client->ca_file)
        opts.ssl->trustStore = mqtts_client->ca_file;

    return MQTTClient_connect(*(mqtts_client->mqtt_client), &opts);
}

int subscribe(mqtts_client_t *mqtts_client,const char *topic) {
    return MQTTClient_subscribe(*(mqtts_client->mqtt_client), topic, 0);
}


int disconnect(mqtts_client_t *mqtts_client) {
    if(mqtts_client->connected) {
        return MQTTClient_disconnect(*(mqtts_client->mqtt_client), 10000);
    }
    return 0;
}


int send_random_dp(mqtts_client_t *mqtts_client) {
    if(!mqtts_client->connected)
        return 0;

    char topic[512] = {'\0'};
    char payload[512] = {'\0'};
    int rand_dp_id = 0;
    int rand_value = 0;
    int rc = 0;

    MQTTClient_deliveryToken token;
    MQTTClient_message pubmsg = MQTTClient_message_initializer;

    //assemble topic
    snprintf(topic,sizeof(topic),base_dp_upload_topic,
             mqtts_client->user_name,mqtts_client->client_id);

    //assemble payload
    srand(time(NULL));

    rand_dp_id = rand() % 100000;
    rand_value = rand() % 10000;

    snprintf(payload,sizeof(payload), base_dp_str,rand_dp_id,rand_value);

    pubmsg.payload = payload;
    pubmsg.payloadlen = strlen(payload);
    pubmsg.qos = 0;
    pubmsg.retained = 0;

    if ((rc = MQTTClient_publishMessage(*(mqtts_client->mqtt_client), topic, &pubmsg, &token)) != MQTTREASONCODE_SUCCESS) {
        printf("failed to start sendMessage, return code %d\n", rc);
    }
    return MQTTClient_waitForCompletion(*(mqtts_client->mqtt_client), token, 10000L);
}
