#ifndef CALC_TOKEN_H_
#define CALC_TOKEN_H_

#include <string.h>
#include <stdint.h>

/**
 * @brief 计算设备鉴权所用的token
 *
 * @param expire_time token过期时间(到什么时刻过期)
 * @param pid 产品id
 * @param device_name 设备名称
 * @param version token使用的版本
 * @param device_access_key 设备级access key
 *
 * @return 完整用于鉴权的token
 */
char *generate_auth_token(int64_t expire_time,const char *pid,
                          const char *device_name,const char *version,
                          const char *device_access_key);
#endif
