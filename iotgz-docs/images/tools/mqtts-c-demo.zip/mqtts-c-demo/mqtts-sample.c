#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <time.h>
#include "token.h"
#include "mqtts-client.h"
#include "call-back.h"
#include "busi.h"

volatile int run = 1;

/**
 * @brief 捕获Linux下SIGINT信号
 *
 * @param signo SIGINT
 */
void sig_handler(int signo) {
    if(signo == SIGINT) {
        printf("[sigint] receive Ctrl + C signal,ready to exit...\n");
        run = 0;
    }
}

int main(int argc,char *argv[]) {
    /*设备所属产品id*/
    const char *pid = "32563";

    /*设备名称*/
    const char *device_name = "MqttsTestDev77";

    /*设备级的access key*/
    const char *device_access_key = "LCy3rbg4rt0bNi2A6PH0do29LjgTK1cC3iFaO8A8BL0=";

    /*鉴权版本,目前为2018-10-31*/
    const char *version = "2018-10-31";

    /*ca证书路径(证书从OneNET官网下载)*/
    const char *ca = "./cert/certificate.pem";

    /*MQTT-TLS服务端地址(从OneNET官网获取)*/
    const char *server_url = "ssl://172.19.19.42:8883";

    /*token过期时间(单位为s),请按照实际具体需求计算token过期时间,本例中为当前时刻的一年后过期*/
    time_t now = time(NULL);
    int64_t expire_time = now + 24 * 60 * 60 * 365;

    if(signal(SIGINT, sig_handler) == SIG_ERR) {
        printf("[sigint] can't catch sigint\n");
        return -1;
    }

    mqtts_client_t *mqtts_client = create_mqtts_client(device_name,
                                   pid,
                                   device_access_key,
                                   expire_time,
                                   version,
                                   ca);
    if(NULL == mqtts_client) {
        printf("create mqtts client failed\n");
        return -1;
    }

    while(run) {
        int rc = connect_to_onenet(mqtts_client, server_url);
        if(0 == rc) {
            printf("[connection] connect to OneNET success...\n");
            mqtts_client->connected = 1;
            break;
        } else {
            printf("[connection] connect to OneNET failed,rc[%d]\n",rc);
            usleep(1000 * 1000 *3);
        }
    }

    busi_loop(mqtts_client);

    disconnect(mqtts_client);

    destroy_mqtts_client(mqtts_client);
    return 0;
}
