
const char *base_subscribe_topic = "$sys/%s/%s/#";
const char *base_dp_upload_topic = "$sys/%s/%s/dp/post/json";
const char *base_cmd_response_topic = "$sys/%s/%s/cmd/response/%s";

const char* base_dp_str = "{"
                          "\"id\":%d,"
                          "\"dp\": {"
                          "\"color\":"
                          "[ {"
                          "\"v\": %d"
                          "}"
                          "]"
                          "}"
                          "}";
