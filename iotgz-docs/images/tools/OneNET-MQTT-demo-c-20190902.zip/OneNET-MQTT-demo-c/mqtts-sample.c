#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include "token.h"
#include "mqtts-client.h"
#include "call-back.h"
#include "busi.h"

volatile int run = 1;

/**
 * @brief 捕获Linux下SIGINT信号
 *
 * @param signo SIGINT
 */
void sig_handler(int signo) {
    if(signo == SIGINT) {
        printf("[sigint] receive Ctrl + C signal,ready to exit...\n");
        run = 0;
    }
}

int main(int argc,char *argv[]) {
    /*设备所属产品id*/
    const char *pid = "您的产品ID";
    /*设备名称*/
    const char *device_name = "您的设备名称";
    /*设备级的access key*/
    const char *device_access_key = "您的设备Key";

    /*鉴权版本,目前为2018-10-31*/
    const char *version = "2018-10-31";
    /*ca证书路径(证书从OneNET官网下载)*/
    const char *ca = "./cert/certificate.pem";
    /*MQTT-TLS服务端地址(从OneNET官网获取)*/
    const char *server_url = "ssl://183.230.40.16:8883";

    /*token过期时间,请按照实际具体需求计算token过期时间,本例中为 从1970-1-1到2019-12-31的秒数*/
    int64_t expire_time = 1577721600;

    if(signal(SIGINT, sig_handler) == SIG_ERR) {
        printf("[sigint] can't catch sigint\n");
        return -1;
    }

    mqtts_client_t *mqtts_client = create_mqtts_client(device_name,pid,
                                   device_access_key,expire_time,version,ca);
    if(NULL == mqtts_client) {
        printf("create mqtts client failed\n");
        return -1;
    }

    while(run) {
        int rc = connect_to_onenet(mqtts_client,server_url);
        if(0 == rc) {
            printf("[connection] connect to OneNET success...\n");
            mqtts_client->connected = 1;
            break;
        } else {
            printf("[connection] connect to OneNET failed,rc[%d]\n",rc);
            usleep(1000 * 1000 *3);
        }
    }

    busi_loop(mqtts_client);

    disconnect(mqtts_client);

    destroy_mqtts_client(mqtts_client);
    return 0;
}
