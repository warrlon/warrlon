#include <openssl/hmac.h>
#include <stdlib.h>
#include <stdio.h>
#include "token.h"
#include "utils.h"


static const char *res_product = "products/";
static const char *res_device = "/devices/";
static const char *sha1_alg = "sha1";

static const char *VERSION_FIELD = "version=";
static const char *RES_FIELD = "&res=";
static const char *ET_FIELD = "&et=";
static const char *METHOD_FIELD = "&method=";
static const char *SIGN_FIELD = "&sign=";

/**
 * @brief 组装生成token 的encrypt data
 *
 * @param expire_time token过期时间(到什么时刻过期)
 * @param pid 产品id
 * @param device_name 设备名称
 * @param version token使用的版本
 * @param device_access_key 设备级access key
 *
 * @return
 */
static char *assemble_encrypt_data(const char *expire_time,const char *pid,
                                   const char *device_name,const char *version,
                                   const char *device_access_key);

/**
 * @brief
 * encrypt_data: expire_time + "\n" + sha1 + "\n" + "products/{pid}/devices/{device_name}" + "\n" + version
 *
 * @param encrypt_data
 * @param encrypt_data_len
 * @param device_access_key 设备级的access key
 *
 * @return token中的签名字段
 */
static char *generate_token_sign(const char *encrypt_data,int encrypt_data_len,
                                 const char *device_access_key);

static char *assemble_auth_token(const char *expire_time,const char *pid,
                                 const char *device_name,const char *version,
                                 const char *url_encoded_sign);

static char *assemble_encrypt_data(const char *expire_time,const char *pid,
                                   const char *device_name,const char *version,
                                   const char *device_access_key) {

    char *encrypt_data = NULL;
    int encrypt_data_len = 0;

    int expire_time_len = strlen(expire_time);
    int pid_len = strlen(pid);
    int device_name_len = strlen(device_name);
    int version_len = strlen(version);

    int res_product_len = strlen(res_product);
    int res_device_len = strlen(res_device);
    int sha1_alg_len = strlen(sha1_alg);

    int index = 0;

    encrypt_data_len += expire_time_len;
    encrypt_data_len += pid_len;
    encrypt_data_len += device_name_len;
    encrypt_data_len += version_len;
    encrypt_data_len += res_product_len;
    encrypt_data_len += res_device_len;
    encrypt_data_len += sha1_alg_len;

    /* three "\n" */
    encrypt_data_len += 3;

    encrypt_data = (char *)malloc(encrypt_data_len + 1);

    /*copy expire time*/
    strncpy(encrypt_data + index,expire_time,expire_time_len);
    index += expire_time_len;

    /*copy "\n"*/
    strncpy(encrypt_data + index,"\n",1);
    index += 1;

    /*copy sha1_alg*/
    strncpy(encrypt_data + index, sha1_alg, sha1_alg_len);
    index += sha1_alg_len;

    /*copy "\n"*/
    strncpy(encrypt_data + index,"\n",1);
    index += 1;

    /*copy resource field*/
    strncpy(encrypt_data + index,res_product,res_product_len);
    index += res_product_len;

    strncpy(encrypt_data + index,pid,pid_len);
    index += pid_len;

    strncpy(encrypt_data + index,res_device,res_device_len);
    index += res_device_len;

    strncpy(encrypt_data + index,device_name,device_name_len);
    index += device_name_len;

    /*copy "\n"*/
    strncpy(encrypt_data + index,"\n",1);
    index += 1;

    /*copy version*/
    strncpy(encrypt_data + index,version,version_len);

    return encrypt_data;
}

static char *generate_token_sign(const char *encrypt_data,
                                 int encrypt_data_len,
                                 const char *device_access_key) {

    if(NULL == encrypt_data || 0 == encrypt_data_len)
        return NULL;

    /*数据经过base64编码后长度最多为origin_len * 4/3 + 2*/
    int sign_len = (int)(EVP_MAX_MD_SIZE * 4 / 3) + 2;
    char *sign = (char *)malloc(sign_len + 1);
    if(NULL == sign) {
        return NULL;
    }

    memset(sign,'\0',sign_len + 1);

    //base64解码device_access_key
    int decrypted_device_access_key_len = calc_base64_decode_length(device_access_key,strlen(device_access_key));
    unsigned char *decrypted_device_access_key = (unsigned char*) malloc(decrypted_device_access_key_len);
    if(NULL == decrypted_device_access_key) {
        free(sign);
        return NULL;
    }

    int rc = base64_decode(device_access_key,strlen(device_access_key),decrypted_device_access_key);
    if(0 != rc) {
        free(sign);
        return NULL;
    }

    /*得到二进制的sha1值*/
    unsigned char sha1[EVP_MAX_MD_SIZE] = {'\0'};
    rc = hmac_sha1((const unsigned char*)encrypt_data,encrypt_data_len,
                   decrypted_device_access_key,decrypted_device_access_key_len,sha1);

    if(rc <= 0) {
        free(sign);
        free(decrypted_device_access_key);
        return NULL;
    }

    /*将二进制的sha1用base64编码*/
    rc = base64_encode(sha1,rc,sign);
    if(0 != rc) {
        free(sign);
        free(decrypted_device_access_key);
        return NULL;
    }

    free(decrypted_device_access_key);

    return sign;
}

char *generate_auth_token(int64_t expire_time,
                          const char *pid,
                          const char *device_name,
                          const char *version,
                          const char *device_access_key) {
    if(0 == expire_time
            || NULL == pid || NULL == device_name
            || NULL == version || NULL == device_access_key)
        return NULL;

    char expire_time_str[64] = {'\0'};
    snprintf(expire_time_str,sizeof(expire_time_str),"%ld",expire_time);

    /*get encrypt_data for calc sign*/
    int encrypt_data_len = 0;
    char *encrypt_data = assemble_encrypt_data(expire_time_str,pid,device_name,version,device_access_key);

    if(NULL == encrypt_data)
        return NULL;

    encrypt_data_len = strlen(encrypt_data);
    char *sign = generate_token_sign(encrypt_data,encrypt_data_len,device_access_key);
    if(NULL == sign) {
        free(encrypt_data);
        return NULL;
    }

    //最多源数据的3倍
    int	sign_len = strlen(sign);
    int url_encoded_sign_len = sign_len * 3;
    char *url_encoded_sign = (char *)malloc(url_encoded_sign_len + 1);
    memset(url_encoded_sign,'\0', url_encoded_sign_len + 1);

    if(NULL == url_encoded_sign) {
        free(encrypt_data);
        free(sign);
        return NULL;
    }

    int rc = url_encode(sign,sign_len,url_encoded_sign,url_encoded_sign_len + 1);
    if(rc < 0) {
        free(encrypt_data);
        free(sign);
        free(url_encoded_sign);
        return NULL;
    }

    char *completed_auth_token = assemble_auth_token(expire_time_str,pid,device_name,version,url_encoded_sign);
    if(NULL == completed_auth_token) {
        free(encrypt_data);
        free(sign);
        free(url_encoded_sign);
        return NULL;
    }

    free(encrypt_data);
    free(sign);
    free(url_encoded_sign);

    return completed_auth_token;
}
static char *assemble_auth_token(const char *expire_time,const char *pid,
                                 const char *device_name,const char *version,
                                 const char *url_encoded_sign) {

    int version_key_len = strlen(VERSION_FIELD);
    int res_key_len = strlen(RES_FIELD);
    int et_key_len = strlen(ET_FIELD);
    int method_key_len = strlen(METHOD_FIELD);
    int sign_key_len = strlen(SIGN_FIELD);

    int expire_time_len = strlen(expire_time);
    int pid_len = strlen(pid);
    int device_name_len = strlen(device_name);
    int version_len = strlen(version);

    int res_product_len = strlen(res_product);
    int res_device_len = strlen(res_device);
    int sha1_alg_len = strlen(sha1_alg);

    int url_encoded_sign_len = strlen(url_encoded_sign);

    int total_token_len = 0;

    total_token_len += strlen(VERSION_FIELD);
    total_token_len += version_len;
    total_token_len += strlen(RES_FIELD);

    //
    total_token_len += res_product_len;
    total_token_len += pid_len;
    total_token_len += res_device_len;
    total_token_len += device_name_len;

    total_token_len += strlen(ET_FIELD);
    total_token_len += expire_time_len;

    total_token_len += strlen(METHOD_FIELD);
    total_token_len += sha1_alg_len;

    total_token_len += strlen(SIGN_FIELD);
    total_token_len += url_encoded_sign_len;


    char *completed_auth_token = (char *)malloc(total_token_len + 1);
    if(NULL == completed_auth_token) {
        return NULL;
    }

    memset(completed_auth_token,'\0',total_token_len + 1);

    //start copy
    int index = 0;
    strncpy(completed_auth_token + index, VERSION_FIELD, version_key_len);
    index += version_key_len;
    strncpy(completed_auth_token + index,version,version_len);
    index += version_len;

    strncpy(completed_auth_token + index,RES_FIELD,res_key_len);
    index += res_key_len;

    strncpy(completed_auth_token + index,res_product,res_product_len);
    index += res_product_len;

    strncpy(completed_auth_token + index,pid,pid_len);
    index += pid_len;

    strncpy(completed_auth_token + index,res_device,res_device_len);
    index += res_device_len;

    strncpy(completed_auth_token + index,device_name,device_name_len);
    index += device_name_len;

    strncpy(completed_auth_token + index,ET_FIELD,et_key_len);
    index += et_key_len;
    strncpy(completed_auth_token + index,expire_time,expire_time_len);
    index += expire_time_len;

    strncpy(completed_auth_token + index,METHOD_FIELD,method_key_len);
    index += method_key_len;
    strncpy(completed_auth_token + index,sha1_alg, sha1_alg_len);
    index += sha1_alg_len;

    strncpy(completed_auth_token + index,SIGN_FIELD,sign_key_len);
    index += sign_key_len;

    strncpy(completed_auth_token + index,url_encoded_sign,url_encoded_sign_len);

    return completed_auth_token;
}
