﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MQDemo_CSharp
{
    public partial class MainWnd : Form
    {
        MQClient mqclient = new MQClient();
        bool isConnected = false;

        public MainWnd()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            mqclient.MessageRecvEvent += showMessage;
        }

        private void buttonConnect_Click(object sender, EventArgs e)
        {
            String brokerAddr = textBoxBrokerServer.Text;
            UInt16 port = Convert.ToUInt16(numericBrokerPort.Value);
            String nsName = textBoxNsName.Text;
            String accesskey = textBoxAccessKey.Text;
            String topic = textBoxTopic.Text;
            String sub = textBoxSubName.Text;

            if (brokerAddr.Equals(""))
            {
                MessageBox.Show("请输入服务器地址","提示");
                return;
            }

            if (nsName.Equals(""))
            {
                MessageBox.Show("请输入实例名称", "提示");
                return;
            }

            if (topic.Equals(""))
            {
                MessageBox.Show("请输入topic名称", "提示");
                return;
            }

            if (sub.Equals(""))
            {
                MessageBox.Show("请输入订阅名称", "提示");
                return;
            }

            if (accesskey.Equals(""))
            {
                MessageBox.Show("请输入accsee-key", "提示");
                return;
            }


            if (!isConnected)
            {
                byte res = mqclient.ConnectSecure(brokerAddr, port, nsName, accesskey);
                if (res == 0)
                {
                    mqclient.Subscribe(nsName, topic, sub);
                    buttonConnect.Text = "断开";
                    AppendAndScrollBottom("连接成功");
                    isConnected = true;
                }
                else
                {
                    AppendAndScrollBottom("连接失败，错误码:" + res);
                    isConnected = false;
                }
            } else
            {
                mqclient.Disconnect();
                isConnected = false;
                buttonConnect.Text = "连接";
            }
        }

        private void showMessage(object sender, MQClient.MQMsgEventArgs args)
        {
            Mq.Msg msg = args.Msg;
            AppendAndScrollBottom(msg.Data.ToStringUtf8());
        }

        private void MainWnd_FormClosing(object sender, FormClosingEventArgs e)
        {
            mqclient.Disconnect();
        }

        private void AppendAndScrollBottom(String text)
        {
            richTextBoxMsg.Text += text + "\n";
            //scroll to bottom
            richTextBoxMsg.SelectionStart = richTextBoxMsg.Text.Length;
            richTextBoxMsg.ScrollToCaret();
        }
    }
}
