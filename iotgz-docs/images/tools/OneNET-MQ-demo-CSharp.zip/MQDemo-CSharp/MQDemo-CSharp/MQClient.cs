﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Security;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using uPLibrary.Networking.M2Mqtt;
using uPLibrary.Networking.M2Mqtt.Messages;
using Mq;

namespace MQDemo_CSharp
{
    class MQClient
    {
        MqttClient mqttClient = null;

        const String certData = "-----BEGIN CERTIFICATE-----\n" +
            "MIIDNTCCAh2gAwIBAgIJAI0j4gYGUcD2MA0GCSqGSIb3DQEBCwUAMDExCzAJBgNV\n" +
            "BAYTAkNOMQ4wDAYDVQQKDAVDTUlPVDESMBAGA1UEAwwJT25lTkVUIE1RMB4XDTE5\n" +
            "MDYxMzAyMTgzM1oXDTQ5MDYwNTAyMTgzM1owMTELMAkGA1UEBhMCQ04xDjAMBgNV\n" +
            "BAoMBUNNSU9UMRIwEAYDVQQDDAlPbmVORVQgTVEwggEiMA0GCSqGSIb3DQEBAQUA\n" +
            "A4IBDwAwggEKAoIBAQDrSdCdWHPwgB1KFo6Gb3nbjVYMbx+3hQ1Qdf+M4+i8MgYz\n" +
            "KSdWTvBf5+eSDEPhAMf7CDbfLtqpEKJPQ8MqcqwRFn5Ahux+bfgzV8QHwsbxqkPz\n" +
            "Z8Ga/2PkL3fJM1Cunq1o4WNRNwgWI0JQbqwEofhuUasJuq63jE7bdzIE60eEjsFw\n" +
            "Tc6ZiRZf9DzQDfI3v0wOKTTfyUlJZgBpQouJBFio9cMW15DvqcT7VmDHd9+gppBa\n" +
            "Wq6Nak+EverpyWW8TaqnwIQRdRwxXu6f8iNQb5UlgW2cUP7pZu0xIY+sE4E94mpV\n" +
            "hZHEmbO3Y8x9Q1r5YwG0oTz+UfCI+toh9OIV2msjAgMBAAGjUDBOMB0GA1UdDgQW\n" +
            "BBSBOGqKT3bVuY6bYlaCfEwryMarIzAfBgNVHSMEGDAWgBSBOGqKT3bVuY6bYlaC\n" +
            "fEwryMarIzAMBgNVHRMEBTADAQH/MA0GCSqGSIb3DQEBCwUAA4IBAQBwSZz/bbpF\n" +
            "yNudik/ZkVIiGkTDC0iPQruZxEghX/UMVSJEpOMOOTz9ws5WUb7B3XWRk85L0YRC\n" +
            "Vh9Axcs7zAiPsVVvPmYO0GkWYzP6MedLyXHMLuoqHSRC6NlgyITXGe7vrClF7YSG\n" +
            "C0nStWF1kQ48RX17Ty5gCsIO/21PIVeXxDXWNhMGs22cLGUR2udGwJQdG5q0ZJwY\n" +
            "hsVDcAQCOP2nuGivh6cP+2acXQH+6C1KMWV4vIk63cC4G1VgXV4ai+Glf6riA8jO\n" +
            "txrtp4v0uwUerArO+wtX/2YXaQWbhYs5+K0dOIi8TltVWiXxyXKqYSsjFbSq0h7F\n" +
            "KZ2I6wtffJnH\n" +
            "-----END CERTIFICATE-----";
        X509Certificate serverCert = new X509Certificate(Encoding.ASCII.GetBytes(certData));

        public byte ConnectSecure(String ip, UInt16 port, String nsName, String accesskey)
        {
            // create client instance
            mqttClient = new MqttClient(ip, port, true, null, null, MqttSslProtocols.TLSv1_2, this.RemoteCertificateValidationCallback);
            
            // register to message received
            mqttClient.MqttMsgPublishReceived += client_MqttMsgPublishReceived;
            mqttClient.MqttMsgSubscribed += client_MqttMsgSubscribed;

            String sastoken = generateSasToken(nsName, accesskey);

            string clientId = Guid.NewGuid().ToString();
            byte res = mqttClient.Connect(clientId, nsName, sastoken);

            return res;
        }

        public void Disconnect()
        {
            if(mqttClient != null && mqttClient.IsConnected)
                mqttClient.Disconnect();
        }

        public void Subscribe(String nsName, String topic, String sub)
        {
            String mqtt_topic = "$sys/pb/consume/" + nsName + "/" + topic + "/" + sub;
            // subscribe to the topic with QoS 1
            mqttClient.Subscribe(new string[] { mqtt_topic }, new byte[] { MqttMsgBase.QOS_LEVEL_AT_LEAST_ONCE });
            
        }

        void client_MqttMsgPublishReceived(object sender, MqttMsgPublishEventArgs e)
        {
            // handle message received
            Console.Out.Write(e.Topic.ToString());

            Mq.Msg msg = Mq.Msg.Parser.ParseFrom(e.Message);
            String data = msg.Data.ToStringUtf8();
            MessageRecvEvent.Invoke(this, new MQMsgEventArgs(msg));
        }

        void client_MqttMsgSubscribed(object sender, MqttMsgSubscribedEventArgs e)
        {
            Console.Out.Write(e.ToString());
        }

        static String generateSasToken(String nsName, String accesskey)
        {
            String res = "mqs/" + nsName;
            String et = String.Format("{0}", DateTimeOffset.UtcNow.ToUnixTimeSeconds() + 30);
            String method = "sha1";
            String version = "2018-10-31";
            
            //base64 decode seckey
            byte[] key = System.Convert.FromBase64String(accesskey);

            //hmacsha1
            HMACSHA1 hmac = new HMACSHA1(key);
            String temp = et + "\n" + method + "\n" + res + "\n" + version;
            String sign = System.Convert.ToBase64String(hmac.ComputeHash(Encoding.ASCII.GetBytes(temp)));

            String sastoken = "method=sha1" +
                "&sign="+ System.Web.HttpUtility.UrlEncode(sign) +
                "&et=" + et +
                "&res=" + System.Web.HttpUtility.UrlEncode(res) +
                "&version=" + version;

            return sastoken;
        }

        bool RemoteCertificateValidationCallback(object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors)
        {
            return serverCert.Equals(certificate);
        }

        public event MessageRecvEventHandler MessageRecvEvent;

        public delegate void MessageRecvEventHandler(object sender, MQMsgEventArgs e);

        public class MQMsgEventArgs : EventArgs
        {
            public MQMsgEventArgs(Mq.Msg msg)
            {
                this.Msg = msg;
            }

            public Mq.Msg Msg { get; }
        }
    }
}
