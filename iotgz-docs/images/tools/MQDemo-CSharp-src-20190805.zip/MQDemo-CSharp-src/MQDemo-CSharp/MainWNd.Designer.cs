﻿namespace MQDemo_CSharp
{
    partial class MainWnd
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainWnd));
            this.buttonConnect = new System.Windows.Forms.Button();
            this.textBoxBrokerServer = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.numericBrokerPort = new System.Windows.Forms.NumericUpDown();
            this.textBoxNsName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxTopic = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxSubName = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBoxAccessKey = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.richTextBoxMsg = new System.Windows.Forms.RichTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.numericBrokerPort)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonConnect
            // 
            this.buttonConnect.Location = new System.Drawing.Point(313, 8);
            this.buttonConnect.Name = "buttonConnect";
            this.buttonConnect.Size = new System.Drawing.Size(75, 23);
            this.buttonConnect.TabIndex = 0;
            this.buttonConnect.Text = "连接";
            this.buttonConnect.UseVisualStyleBackColor = true;
            this.buttonConnect.Click += new System.EventHandler(this.buttonConnect_Click);
            // 
            // textBoxBrokerServer
            // 
            this.textBoxBrokerServer.Location = new System.Drawing.Point(70, 6);
            this.textBoxBrokerServer.Name = "textBoxBrokerServer";
            this.textBoxBrokerServer.Size = new System.Drawing.Size(119, 25);
            this.textBoxBrokerServer.TabIndex = 1;
            this.textBoxBrokerServer.Text = "183.230.40.96";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 15);
            this.label1.TabIndex = 2;
            this.label1.Text = "服务器";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(195, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "端口";
            // 
            // numericBrokerPort
            // 
            this.numericBrokerPort.Location = new System.Drawing.Point(238, 6);
            this.numericBrokerPort.Maximum = new decimal(new int[] {
            65535,
            0,
            0,
            0});
            this.numericBrokerPort.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericBrokerPort.Name = "numericBrokerPort";
            this.numericBrokerPort.Size = new System.Drawing.Size(69, 25);
            this.numericBrokerPort.TabIndex = 3;
            this.numericBrokerPort.Value = new decimal(new int[] {
            8883,
            0,
            0,
            0});
            // 
            // textBoxNsName
            // 
            this.textBoxNsName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.textBoxNsName.Location = new System.Drawing.Point(105, 39);
            this.textBoxNsName.Name = "textBoxNsName";
            this.textBoxNsName.Size = new System.Drawing.Size(149, 25);
            this.textBoxNsName.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 45);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "实例名称";
            // 
            // textBoxTopic
            // 
            this.textBoxTopic.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.textBoxTopic.Location = new System.Drawing.Point(313, 39);
            this.textBoxTopic.Name = "textBoxTopic";
            this.textBoxTopic.Size = new System.Drawing.Size(90, 25);
            this.textBoxTopic.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(260, 45);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(47, 15);
            this.label4.TabIndex = 2;
            this.label4.Text = "topic";
            // 
            // textBoxSubName
            // 
            this.textBoxSubName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.textBoxSubName.Location = new System.Drawing.Point(454, 39);
            this.textBoxSubName.Name = "textBoxSubName";
            this.textBoxSubName.Size = new System.Drawing.Size(90, 25);
            this.textBoxSubName.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(411, 45);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(37, 15);
            this.label5.TabIndex = 2;
            this.label5.Text = "订阅";
            // 
            // textBoxAccessKey
            // 
            this.textBoxAccessKey.Location = new System.Drawing.Point(105, 77);
            this.textBoxAccessKey.Name = "textBoxAccessKey";
            this.textBoxAccessKey.Size = new System.Drawing.Size(439, 25);
            this.textBoxAccessKey.TabIndex = 1;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 83);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(87, 15);
            this.label6.TabIndex = 2;
            this.label6.Text = "access-key";
            // 
            // richTextBoxMsg
            // 
            this.richTextBoxMsg.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.richTextBoxMsg.Location = new System.Drawing.Point(15, 119);
            this.richTextBoxMsg.Name = "richTextBoxMsg";
            this.richTextBoxMsg.ReadOnly = true;
            this.richTextBoxMsg.Size = new System.Drawing.Size(530, 236);
            this.richTextBoxMsg.TabIndex = 5;
            this.richTextBoxMsg.Text = "";
            // 
            // MainWnd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(557, 367);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBoxNsName);
            this.Controls.Add(this.textBoxTopic);
            this.Controls.Add(this.richTextBoxMsg);
            this.Controls.Add(this.textBoxSubName);
            this.Controls.Add(this.numericBrokerPort);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.textBoxAccessKey);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxBrokerServer);
            this.Controls.Add(this.buttonConnect);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(575, 414);
            this.Name = "MainWnd";
            this.Text = "OneNET MQ Demo";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainWnd_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numericBrokerPort)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonConnect;
        private System.Windows.Forms.TextBox textBoxBrokerServer;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown numericBrokerPort;
        private System.Windows.Forms.TextBox textBoxNsName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxTopic;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxSubName;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBoxAccessKey;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.RichTextBox richTextBoxMsg;
    }
}

